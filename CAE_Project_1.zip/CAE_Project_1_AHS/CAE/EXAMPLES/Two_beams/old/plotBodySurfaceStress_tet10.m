function plotBodySurfaceStress_tet10(Nodes,elist,stressVec)

% This function is plotting 3D surface of FE mesh using tet10 element

numOfElements = size(elist,1);

numOfContourColors = 10;
colorMat = colormap(jet(numOfContourColors));
mappedStressContour = linspace(min(stressVec),max(stressVec),numOfContourColors);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    
    elementStress = stressVec(elist(nn,1));
    
    [~, mappedStressContourID] = sort(abs(mappedStressContour-elementStress));
    surfColor = colorMat(mappedStressContourID(1),:);
    
    ncoord = Nodes(elementNodes([2 5 1 7 3 6]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([1 5 2 9 4 8]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([2 6 3 10 4 9]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([3 7 1 8 4 10]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
end
