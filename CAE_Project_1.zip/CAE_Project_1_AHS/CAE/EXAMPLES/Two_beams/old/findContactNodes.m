

% ----------------------------------------
% GENERAL INSTRUCTIONS FOR SEARCHING NODES
%-----------------------------------------

% Global cartesian coordinate system with min max limits
% nodeSearchCoordinates = [X_min, X_max, Y_min, Y_max, Z_min, Z_max];
% function inputs: 'cartesian','limits'

% Global cartesian" coordinate system with location and +/- tolerance
% nodeSearchCoordinates = [X, (+/-)X, Y, (+/-)Y, Z, (+/-)Z];
% function inputs: 'cartesian','tolerance'

% Global cartesian coordinate system with min max limits
% nodeSearchCoordinates = [X_min, X_max, Y_min, Y_max, Z_min, Z_max];
% function inputs: 'cylindrical','limits'

% Global cylindrical coordinate system with location and +/- tolerance
% nodeSearchCoordinates = [X, (+/-)X, Y, (+/-)Y, Z, (+/-)Z];
% function inputs: 'cylindrical','tolerance'


% bodyID = 2;
% bodyNodes = findBodyNodes(elist.body{bodyID});
% COStype = 'cartesian';
% nodeSearchCoordinates = [0.9-1e-4 1+1e-4 0.1-1e-4 0.1+1e-4 0-1e-4 0.1+1e-4];
% foundNodes = searchNodesBasedOnCoordinates(Nodes(bodyNodes,:),nodeSearchCoordinates,COStype,'limits');
% plotConstraintNodes(Nodes,elist.body{bodyID},foundNodes,COStype)
% 
% sourceNodes = foundNodes;


bodyID = 1;
bodyNodes = findBodyNodes(elist.body{bodyID});
COStype = 'cartesian';
nodeSearchCoordinates = [1-1e-4 1+1e-4 -1 1 -1 1];
foundNodes = searchNodesBasedOnCoordinates(Nodes(bodyNodes,:),nodeSearchCoordinates,COStype,'limits');
plotConstraintNodes(Nodes,elist.body{bodyID},foundNodes,COStype)

F_nodes = foundNodes;
% targetNodes = foundNodes;

% contactNodesPairs = [];
% % Finding source-target pairs by using shortest distance approach
% for nn = 1:length(sourceNodes)
%     
%     distances = sqrt((Nodes(targetNodes,2)-Nodes(sourceNodes(nn),2)).^2 ...
%     +(Nodes(targetNodes,3)-Nodes(sourceNodes(nn),3)).^2 ...
%     +(Nodes(targetNodes,4)-Nodes(sourceNodes(nn),4)).^2);
% 
%     [distances_sorted, distances_id] = sort(distances);
%     
%     contactNodesPairs = [contactNodesPairs; sourceNodes(nn) targetNodes(distances_id(1))];
% end

% Adding interference
% addingInterference

% % Plotting source-target pairs
% figure
% hold on
% 
% for nn = 1:size(contactNodesPairs,1)
%     
%     plot3([Nodes(contactNodesPairs(nn,1),2) Nodes(contactNodesPairs(nn,2),2)], ...
%         [Nodes(contactNodesPairs(nn,1),3) Nodes(contactNodesPairs(nn,2),3)], ...
%         [Nodes(contactNodesPairs(nn,1),4) Nodes(contactNodesPairs(nn,2),4)],'r-')
% end
