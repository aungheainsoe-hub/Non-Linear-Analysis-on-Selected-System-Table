function plotFullAssemblyElementalStress(Nodes,elist,Uvec,stressVec)

% This function plots assembly elemental stress distribution

numOfNodes = size(Nodes,1);

Umat = [zeros(numOfNodes,1) reshape(Uvec,3,numOfNodes)'];

% Automatic deformation factor
NodesMax = max(max(abs(Nodes(:,2:4))));
defFactor = 0.10*NodesMax/max(abs(Umat(:)));
if defFactor > 1e9
    defFactor = 1;
end

plotFullAssemblyStress(Nodes+defFactor*Umat,elist,stressVec)
title(['Deformation factor ' num2str(defFactor)])

caxis([min(stressVec) max(stressVec)]);
h = colorbar;
ylabel(h, 'Elemental stress (Pa)')
