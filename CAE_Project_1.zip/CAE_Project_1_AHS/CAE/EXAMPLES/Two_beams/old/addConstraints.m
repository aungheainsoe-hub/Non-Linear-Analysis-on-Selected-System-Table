
% ----------------------------------------
% GENERAL INSTRUCTIONS FOR SEARCHING NODES
%-----------------------------------------

% Global cartesian coordinate system with min max limits
% nodeSearchCoordinates = [X_min, X_max, Y_min, Y_max, Z_min, Z_max];
% function inputs: 'cartesian','limits'

% Global cartesian" coordinate system with location and +/- tolerance
% nodeSearchCoordinates = [X, (+/-)X, Y, (+/-)Y, Z, (+/-)Z];
% function inputs: 'cartesian','tolerance'

% Global cartesian coordinate system with min max limits
% nodeSearchCoordinates = [X_min, X_max, Y_min, Y_max, Z_min, Z_max];
% function inputs: 'cylindrical','limits'

% Global cylindrical coordinate system with location and +/- tolerance
% nodeSearchCoordinates = [X, (+/-)X, Y, (+/-)Y, Z, (+/-)Z];
% function inputs: 'cylindrical','tolerance'


bodyID = 1;
bodyNodes = findBodyNodes(elist.body{bodyID});
COStype = 'cartesian';
nodeSearchCoordinates = [-0.01 0.001 -1 1 -1 1];
foundNodes = searchNodesBasedOnCoordinates(Nodes(bodyNodes,:),nodeSearchCoordinates,COStype,'limits');
% plotConstraintNodes(Nodes,elist.body{bodyID},foundNodes,COStype)

Kmat = addConstraints_3D(Kmat,foundNodes,[1e16 1e16 1e16]);

bodyID = 2;
bodyNodes = findBodyNodes(elist.body{bodyID});
COStype = 'cartesian';
nodeSearchCoordinates = [1.9-1e-3 1.9+1e-3 -1 1 -1 1];
foundNodes = searchNodesBasedOnCoordinates(Nodes(bodyNodes,:),nodeSearchCoordinates,COStype,'limits');
% plotConstraintNodes(Nodes,elist.body{bodyID},foundNodes,COStype)

Kmat = addConstraints_3D(Kmat,foundNodes,[1e16 1e16 1e16]);
