
numOfDofs = size(Kmat,1);
numOfNodes = size(Nodes,1);

Fvec = zeros(numOfDofs,1);

% Uvec = Kmat\Fvec;
% Now there is now external loads, therefore Uvec is initially
Uvec = zeros(numOfDofs,1);

% Initializing contact force vector
F_contact = zeros(numOfDofs,1);

% Contact stiffness
contactStiffness = 1e4;

% Current iteration step
iterationNum = 0;

% Allowed error in contact distance
e_tol = 1e-7; %# ---------------------------------------------------------

figure
hold on
grid
ylabel('max(Residual interference) (\mu m)')
xlabel('Iterations')

disp('Iterating contact...')

while 1
    
    % Nodal deformations
    Umat = [zeros(numOfNodes,1) reshape(Uvec,3,numOfNodes)'];
    % Contact node pairs' interference
    delta_u = (Nodes(sourceNodes,3)+Umat(sourceNodes,3))-(Nodes(targetNodes,3)+Umat(targetNodes,3));
    
    % Determines which source-target pairs have residual interference
    logicVec = ~(-e_tol < delta_u);
    
    if sum(logicVec) > 0 % there are nodes with residual interference left
        
        % Source nodes
        F_contact(3*sourceNodes-1) = F_contact(3*sourceNodes-1) ...
            -contactStiffness*delta_u.*logicVec;
        
        % Target nodes
        F_contact(3*targetNodes-1) = F_contact(3*targetNodes-1) ...
            +contactStiffness*delta_u.*logicVec;
        
    else
        break
    end
    
    iterationNum = iterationNum+1;
    
    Uvec = Kmat\(Fvec+F_contact);
    
    if iterationNum == 1 % storing initial delta_u
        delta_u_old = max(abs(delta_u.*logicVec));
    end
    
    semilogy(iterationNum-1:iterationNum,1e6*[delta_u_old max(abs(delta_u.*logicVec))],'b-')
    drawnow
    
    delta_u_old = max(abs(delta_u.*logicVec));
    
end

disp(['Equilibrium found with ' num2str(iterationNum) ' iterations'])

% Automatic deformation factor
NodesMax = max(max(abs(Nodes(:,2:4))));
defFactor = 0.10*NodesMax/max(abs(Umat(:)));
if defFactor > 1e9
    defFactor = 1;
end

plotFullAssembly(Nodes+defFactor*Umat,elist)
title(['deformation factor ' num2str(defFactor)])

