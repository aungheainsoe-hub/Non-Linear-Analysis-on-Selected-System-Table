function plotBodySurface3DStress(Nodes,elist,stressVec)

% This function is plotting 3D surface of FE mesh

% Detecting element type used
elementNodes = size(elist,2);

if elementNodes == 9 % hex8 element
    plotBodySurfaceStress_hex8(Nodes,elist,stressVec)
    
elseif elementNodes == 11 % tet10 element
    plotBodySurfaceStress_tet10(Nodes,elist,stressVec)
    
elseif elementNodes == 21 % hex20 element
    plotBodySurfaceStress_hex20(Nodes,elist,stressVec)
    
else
    disp('Element type was not detected successfully.')
end
