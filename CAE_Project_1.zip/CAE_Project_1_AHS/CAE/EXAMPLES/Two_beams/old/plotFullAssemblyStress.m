function plotFullAssemblyStress(Nodes,elist,stressVec)

% This function plots the full assembly

figure
hold on

for bodyID = 1:size(elist.body,2)
    plotBodySurface3DStress(Nodes,elist.body{bodyID},stressVec)
end

addQuiver3()
