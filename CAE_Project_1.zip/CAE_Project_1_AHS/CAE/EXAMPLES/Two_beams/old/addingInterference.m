
% Shifting whole body
bodyID = 2;
bodyNodes = findBodyNodes(elist.body{bodyID});
% plotConstraintNodes(Nodes,elist.body{bodyID},bodyNodes,COStype)

% Shifting Y-coords
Nodes(bodyNodes,3) = Nodes(bodyNodes,3)-0.1e-3;
