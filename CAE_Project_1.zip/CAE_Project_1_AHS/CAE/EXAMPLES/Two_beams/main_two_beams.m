clear all, close all, clc

inputFile = 'ds.dat';

[Nodes, elist] = readANSYSinputFile(inputFile);

NS = readANSYSnamedSelection(inputFile);

% readANSYScontacts(inputFile);


for nn = 1:length(elist.body)
bodyID = nn;
figure
hold on
plotBodySurfaceNodes(Nodes,elist.body{bodyID},NS.ALL_SURFACES)
addQuiver3
title(['Body ' num2str(bodyID)])
end


% Materials
steel.E = 200e9;
steel.nu = 0.3;
steel.rho = 7850;

aluminum.E = 68e9;
aluminum.nu = 0.33;
aluminum.rho = 2770;


% Generate body global matrices
bodyID = 1;
material(bodyID) = steel;
Kmat = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'stiff',[]);
Mmat = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'mass',[]);
Gmat = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'gyro',[]);

bodyID = 2;
material(bodyID) = aluminum;
KmatN = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'stiff',[]);
MmatN = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'mass',[]);
GmatN = generateBodyMatrices3D(material(bodyID),Nodes,elist.body{bodyID},bodyID,'gyro',[]);

Kmat = Kmat+KmatN;
Mmat = Mmat+MmatN;
Gmat = Gmat+GmatN;
clear KmatN MmatN GmatN


% Solve eigenmodes
[Freq, FiiN] = solveEigenModes(Kmat,Mmat,20); % last: num of lowest modes

% Plot desired eigenmodes
for n = 6:20
    plotEigenModeAsSurfaceNodes(Nodes,elist,Freq,FiiN,NS.ALL_SURFACES,n);
end

