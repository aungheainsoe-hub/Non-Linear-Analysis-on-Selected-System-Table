function NS = readANSYSnamedSelection(inputFile)

% This function extracts named selection from input file
%
% Format: NS.[nameN] = [], size of n x 1

fileHandle = fopen(inputFile, 'r');

% Creating an empty variable
NS = [];

while 1
    line = fgets(fileHandle);
    
    if line == -1
        break
    end
    
    % Detecting start of named selection and the name used
    if strncmpi(line,'CMBLOCK',7)
        
        % Making a new vector list
        line = strsplit(line,',');
        
        % Name of the named selection given in Ansys
        varName = line{2};
        
        % Number of NS nodes and rows in the list (max 8 nodes per row)
        numOfNodes = str2num(line{4});
        numOfRows = ceil(numOfNodes/8);
        
        eval(['NS.' varName ' = [];']);
        
        % Reading line before node list start
        line = fgets(fileHandle);
        
        for nn = 1:numOfRows
            line = fgets(fileHandle);
            
            nodesN = str2num(line);
            
            eval(['NS.' varName ' = [NS.' varName '; nodesN(:)];']);
        end
    end
    if (strncmpi(line,'/com,*********** Define Temperature Constraint ***********',58))
        break
    end
    
end

fclose(fileHandle);
