function Kmat = addConstraints_3D(Kmat,foundNodes,kVec)

% This function adds spring coefficients to stiffness matrix.
% With this function you can add simple bearing properties, or
% add stiff springs that works similarly than constraints.
% The spring vector kVec has stiffness terms for all dofs UX, UY, UZ for 
% one single node.

% kVec = [kb_x kb_y kb_z];

numOfFoundNodes = length(foundNodes);

for nn = 1:numOfFoundNodes
    
    Kmat(3*foundNodes(nn)-2:3*foundNodes(nn),3*foundNodes(nn)-2:3*foundNodes(nn)) = ...
        Kmat(3*foundNodes(nn)-2:3*foundNodes(nn),3*foundNodes(nn)-2:3*foundNodes(nn)) ...
        +diag(kVec/numOfFoundNodes);
    
end
