function matN = generateBodyMatrices3D(material,Nodes,elist,bodyID,matrixType,info)

% This function generates global stiffness, mass and gyroscopic matrices
% for a single body

numOfNodes = size(Nodes,1);
numOfDofs = 3*numOfNodes;
numOfElements = size(elist,1);

% Allocating empty full matrices for collecting coordinates and
% coefficients of NNZs of structural matrices. Later sparse structural
% matrices will be generated based on these collected data

matN_MNX = zeros(900*numOfElements,3); % tet10 ke has 3600 NNZs
matN_Cells = 0; % total number of NNZ stiffness cells

% Empty vector for element volumes
%Vmesh = zeros(numOfElements,1);

globalMatrixAssemblyStartTime = now;
% h  = waitbar(0,['Assembling global matrices for body ' num2str(bodyID)]);
disp(['Assembling global ' matrixType ' matrix for body ' num2str(bodyID) ' ...'])

for nn = 1:numOfElements
    tic
    %disp(['Assembling element ' num2str(nn) '/' num2str(numOfElements)])
    % waitbar(nn/numOfElements)
    
    elementNodes = elist(nn,2:end);
    
    NodalCoordinates = Nodes(elementNodes,2:4);
    
    if strcmpi(matrixType,'stiff')
        matrix = tet10Kmat(material,NodalCoordinates);
        trilM = tril(matrix);
        matrix = trilM+trilM'-diag(diag(matrix));
        
    elseif strcmpi(matrixType,'mass')
        matrix = tet10Mmat(material,NodalCoordinates);
        
    elseif strcmpi(matrixType,'gyro')
        matrix = tet10Gmat(material,NodalCoordinates);
        
    elseif strcmpi(matrixType,'stresstiff')
        stressVec = info(:,nn);
        matrix = tet10KGmat(NodalCoordinates,stressVec);
        
    elseif strcmpi(matrixType,'convstiff')
        matrix = tet10Smat(material,NodalCoordinates);
        
    else
        disp('Unknown matrix type')
    end
    
    %Ve = tet10Volume(NodalCoordinates);
    
    % Storing NNZ terms and coordinates
    [matN_MNX, matN_Cells] = assembleGlobalMatrix3D(matrix,elementNodes,matN_MNX,matN_Cells);
    
    % Storing element volumes
    %Vmesh(nn) = Ve;
end


matN_M = matN_MNX(:,1);
matN_N = matN_MNX(:,2);
matN_X = matN_MNX(:,3);
clear matN_MNX

matN_M(matN_M == 0) = [];
matN_N(matN_N == 0) = [];
matN_X(matN_X == 0) = [];
Kmat_nn = max([max(matN_M) max(matN_N)]);

matN = sparse(matN_M,matN_N,matN_X,numOfDofs,numOfDofs);


% delete(h)
meshingEndTime = now -globalMatrixAssemblyStartTime;
disp(['Global ' matrixType ' matrix assembly completed for body ' num2str(bodyID)])
disp(['Global ' matrixType ' matrix assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
