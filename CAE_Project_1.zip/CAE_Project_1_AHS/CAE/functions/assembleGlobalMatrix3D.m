function [Mat_MNX, Mmat_Cells] = assembleGlobalMatrix3D(elementMat,elementNodes,Mat_MNX,Mmat_Cells)

% This function assembles global matrix from a single 3D element matrix
for nn = 1:length(elementNodes)
    for mm = 1:length(elementNodes)
        %
        for dof1 = 1:3
            for dof2 = 1:3
                %
                if elementMat(3*nn-3+dof1,3*mm-3+dof2) ~= 0
                    
                    Mmat_Cells = Mmat_Cells +1;
                    Mat_MNX(Mmat_Cells,:) = [3*elementNodes(nn)-3+dof1,3*elementNodes(mm)-3+dof2 elementMat(3*nn-3+dof1,3*mm-3+dof2)];
                end
            end
        end
    end
end
