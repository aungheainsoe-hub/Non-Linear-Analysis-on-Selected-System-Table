function [Freq, FiiN] = solveEigenModes(Kmat,Mmat,lowestModes)

% This function solves used defined number of eigenvalues and eigenvectors 
% using stiffness and mass matrices to be used for studying the eigenmodes 
% or as part of modal reduction

disp('Solving eigenvalue problem...')
tic
[FiiN, D] = eigs(Kmat,Mmat,lowestModes,'sm');
[Freq, indx] = sort(real(sqrt(diag(D)))/(2*pi));
FiiN = FiiN(:,indx);
toc
disp('Done')
