function [Nodes, elist] = readANSYSinputFile(inputFile)

% This function extracts node coordinate list and element list with proper
% node order from ANSYS input file.
%
% format: Nodes = [nodeID X-coord Y-coord Z-coord]
%
% format: elist.body{n} = [elementID [node1..nodeN]]

fileHandle = fopen(inputFile, 'r');

% The nth node detected
numOfNodes = 0;

% The nth body detected
bodyIDdetected = 0;

while 1
    line = fgets(fileHandle);
    
    if line == -1
        break
    end
    
    if strncmpi(line,'!Material Id',12)
        break
    end
    
    % Detecting number of nodes for preallocation, storing them later
    if strncmpi(line,'nblock',6)
        
        % Reading line before node list start
        line = fgets(fileHandle);
        
        while 1
            line = fgets(fileHandle);
            
            if strncmpi(line,'-1',2)
                break
            end
            
            numOfNodes = numOfNodes +1;
        end
    end
    
    % Detecting start of body nodes list
    if strncmpi(line,'/com,*********** Elements for Body',34)
        bodyIDdetected = bodyIDdetected +1;
        
        % Detecting element type
        line = fgets(fileHandle);
        lineSplitted = strsplit(line,',');
        elementType = str2double(lineSplitted(end));
    end
    
    if strncmpi(line,'eblock',6)
        % Detecting the number of element in body n
        lineSplitted = strsplit(line,',');
        numOfElementsInBodyN = str2double(lineSplitted(end));
        
        % Reading line before element list start
        line = fgets(fileHandle);
        
        % Allocating matrix for nth body element list
        if elementType == 185 % SOLID185, 8-node hexahedron
            elist.body{bodyIDdetected} = zeros(numOfElementsInBodyN,1+8);
            
        elseif elementType == 186 % SOLID186, 20-node hexahedron
            elist.body{bodyIDdetected} = zeros(numOfElementsInBodyN,1+20);
            
        elseif elementType == 187 % SOLID187, 10-node tetrahedron
            elist.body{bodyIDdetected} = zeros(numOfElementsInBodyN,1+10);
        else
            disp('Unknown element type, detection failed!')
        end
        
        % Element index of body n
        NthElement = 0;
        
        while 1
            line = fgets(fileHandle);
            
            if strncmpi(line,'-1',2)
                break
            end
            
            NthElement = NthElement +1;
            
            nodesLine1 = str2num(line);
            
            % SOLID185 node list is one row long but,
            % SOLID186 and SOLID187 node list is two rows long
            if elementType == 186 || elementType == 187
                line = fgets(fileHandle);
                nodesLine2 = str2num(line);
            end
            
            if elementType == 185
                elist.body{bodyIDdetected}(NthElement,:) = nodesLine1(11:end);
                
            elseif elementType == 186 || elementType == 187
                elist.body{bodyIDdetected}(NthElement,:) = ...
                [nodesLine1(11:end) nodesLine2];
            
            else
                disp('Unknown element type, storing failed!')
            end
        end
    end
end

fclose(fileHandle);

% Reopening file for reading node coordinates
fileHandle = fopen(inputFile, 'r');

Nodes = zeros(numOfNodes,4);

NthNode = 0;

while 1
    line = fgets(fileHandle);
    
    if line == -1
        break
    end
    
    % Detecting number of nodes for preallocation, storing them later
    if strncmpi(line,'nblock',6)
        
        % Reading line before node list start
        line = fgets(fileHandle);
        
        while 1
            
            line = fgets(fileHandle);
            
            if strncmpi(line,'-1',2)
                break
            end
            
            NthNode = NthNode +1;
            
            Nodes(NthNode,:) = str2num(line);
        end
    end
end

fclose(fileHandle);
