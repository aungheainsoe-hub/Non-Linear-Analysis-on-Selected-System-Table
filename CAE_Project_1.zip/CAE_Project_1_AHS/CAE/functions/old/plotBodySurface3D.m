function plotBodySurface3D(Nodes,elist)

% This function is plotting 3D surface of FE mesh

% Detecting element type used
elementNodes = size(elist,2);

if elementNodes == 9 % hex8 element
    plotBodySurface_hex8(Nodes,elist)
    
elseif elementNodes == 11 % tet10 element
    plotBodySurface_tet10(Nodes,elist)
    
elseif elementNodes == 21 % hex20 element
    plotBodySurface_hex20(Nodes,elist)
    
else
    disp('Element type was not detected successfully.')
end
