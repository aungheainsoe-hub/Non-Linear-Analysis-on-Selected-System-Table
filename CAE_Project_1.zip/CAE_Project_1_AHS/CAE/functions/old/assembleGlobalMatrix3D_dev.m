function globalMat = assembleGlobalMatrix3D(elementMat,elementNodes,numOfDofs)

% This function assembles global matrix from a single 3D element matrix

% Allocating empty matrix with nnz terms enough for single element
globalMat = spalloc(numOfDofs,numOfDofs,0);

for nn = 1:length(elementNodes)
    
    GMtemp = spalloc(numOfDofs,numOfDofs,0);
    
    for mm = 1:length(elementNodes)
        %
        for dof1 = 1:3
            for dof2 = 1:3
                %
                if elementMat(3*nn-3+dof1,3*mm-3+dof2) ~= 0
                    
                    GMtemp(3*elementNodes(nn)-3+dof1,3*elementNodes(mm)-3+dof2) = ...
                        elementMat(3*nn-3+dof1,3*mm-3+dof2);
                end
            end
        end
    end
    
    globalMat = globalMat +GMtemp;
    
end
