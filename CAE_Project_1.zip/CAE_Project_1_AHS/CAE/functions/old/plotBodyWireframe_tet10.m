function plotBodyWireframe_tet10(Nodes,elist)

% This function is plotting 3D wireframe of FE mesh using tet10 element

numOfElements = size(elist,1);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    ncoord = Nodes(elementNodes,2:4);
    
    plot3(ncoord([1 5 2],1),ncoord([1 5 2],2),ncoord([1 5 2],3),'b-')
    plot3(ncoord([1 7 3],1),ncoord([1 7 3],2),ncoord([1 7 3],3),'b-')
    plot3(ncoord([1 8 4],1),ncoord([1 8 4],2),ncoord([1 8 4],3),'b-')
    plot3(ncoord([2 6 3],1),ncoord([2 6 3],2),ncoord([2 6 3],3),'b-')
    plot3(ncoord([3 10 4],1),ncoord([3 10 4],2),ncoord([3 10 4],3),'b-')
    plot3(ncoord([4 9 2],1),ncoord([4 9 2],2),ncoord([4 9 2],3),'b-')
    
end
