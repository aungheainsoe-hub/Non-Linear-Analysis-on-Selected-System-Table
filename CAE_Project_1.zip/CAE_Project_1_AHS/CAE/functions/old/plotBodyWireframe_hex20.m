function plotBodyWireframe_hex20(Nodes,elist)

% This function is plotting 3D wireframe of FE mesh using hex20 element

numOfElements = size(elist,1);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    ncoord = Nodes(elementNodes,2:4);
    
    plot3(ncoord([1 9 2],1),ncoord([1 9 2],2),ncoord([1 9 2],3),'b-')
    plot3(ncoord([2 10 3],1),ncoord([2 10 3],2),ncoord([2 10 3],3),'b-')
    plot3(ncoord([3 11 4],1),ncoord([3 11 4],2),ncoord([3 11 4],3),'b-')
    plot3(ncoord([4 12 1],1),ncoord([4 12 1],2),ncoord([4 12 1],3),'b-')
    plot3(ncoord([5 13 6],1),ncoord([5 13 6],2),ncoord([5 13 6],3),'b-')
    plot3(ncoord([6 14 7],1),ncoord([6 14 7],2),ncoord([6 14 7],3),'b-')
    plot3(ncoord([7 15 8],1),ncoord([7 15 8],2),ncoord([7 15 8],3),'b-')
    plot3(ncoord([8 16 5],1),ncoord([8 16 5],2),ncoord([8 16 5],3),'b-')
    plot3(ncoord([1 17 5],1),ncoord([1 17 5],2),ncoord([1 17 5],3),'b-')
    plot3(ncoord([2 18 6],1),ncoord([2 18 6],2),ncoord([2 18 6],3),'b-')
    plot3(ncoord([3 19 7],1),ncoord([3 19 7],2),ncoord([3 19 7],3),'b-')
    plot3(ncoord([4 20 8],1),ncoord([4 20 8],2),ncoord([4 20 8],3),'b-')
    
end
