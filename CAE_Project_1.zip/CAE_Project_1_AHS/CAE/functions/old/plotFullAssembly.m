function plotFullAssembly(Nodes,elist)

% This function plots the full assembly

figure
hold on

for bodyID = 1:size(elist.body,2)
    plotBodySurface3D(Nodes,elist.body{bodyID})
end

addQuiver3()
