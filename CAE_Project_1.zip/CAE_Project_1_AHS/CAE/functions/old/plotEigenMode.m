function plotEigenMode(Nodes,elist,Freq,V,eigenmodeNumber)

% This functions plot a single requested eigenmode

numOfNodes = size(Nodes,1);

% Automatic deformation factor
defo = [zeros(numOfNodes,1) reshape(real(V(:,eigenmodeNumber)),3,numOfNodes)'];
NodesMax = max(max(abs(Nodes(:,2:4))));
defFactor = 0.10*NodesMax/max(abs(defo(:)));
if defFactor > 1e9
    defFactor = 1;
end

displacement_matrix = Nodes+[zeros(numOfNodes,1) ...
    defFactor*reshape(real(V(:,eigenmodeNumber)),3,numOfNodes)'];

% Number of bodies
numOfBodies = size(elist.body,2);

figure
hold on

for bodyID = 1:numOfBodies
    plotBodySurface3D(displacement_matrix,elist.body{bodyID})
end
addQuiver3()

title(['Eigenmode ' num2str(eigenmodeNumber) ', ' num2str(real(Freq(eigenmodeNumber))) ' Hz, deformation factor ' num2str(defFactor)])
