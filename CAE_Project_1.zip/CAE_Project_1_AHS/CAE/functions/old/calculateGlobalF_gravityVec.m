function F_gravityVec = calculateGlobalF_gravityVec(material,Nodes,elist,accelerationVec)

% This function calculates element gravity force vectors for full
% assembly

numOfDofs = 3*size(Nodes,1);

F_gravityVec = zeros(numOfDofs,1);

fprintf('Assembling global F_gravityVec for body ');

globalMatrixAssemblyStartTime = now;

% Loop for calculating element centrifugal force vector
for bodyID = 1:size(elist.body,2)
    
    % h  = waitbar(0,['Assembling global F OmegaVec for body ' num2str(bodyID)]);
    %disp(['Assembling global F OmegaVec for body ' num2str(bodyID) ' ...'])
    
    if bodyID == 1
        fprintf('%d',bodyID);
    else
        fprintf(', %d',bodyID);
    end
    
    elistBodyN = elist.body{bodyID};
    
    numOfElements = size(elistBodyN,1);
    
    for nn = 1:numOfElements
        
        % waitbar(nn/numOfElements)
        
        elementNodes = elistBodyN(nn,2:end);
        NodalCoordinates = Nodes(elementNodes,2:4);
        
        if length(elementNodes) == 8 % hex8 element
            F_gravityElementVec = hex8F_gravityVec(material(bodyID),NodalCoordinates,accelerationVec);
            
        elseif length(elementNodes) == 10 % tet10 element
            F_gravityElementVec = tet10F_gravityVec(material(bodyID),NodalCoordinates,accelerationVec);
            
        elseif length(elementNodes) == 20 % hex20 element
            F_gravityElementVec = hex20F_gravityVec(material(bodyID),NodalCoordinates,accelerationVec);
            
        else
            disp('Unknown element type')
        end
        
        F_gravityVec = F_gravityVec +assembleGlobalForceVector(F_gravityElementVec,elementNodes,numOfDofs);
    end
    
    % delete(h)
end

meshingEndTime = now -globalMatrixAssemblyStartTime;
fprintf('\n');
disp(['Global F_gravityVec assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
