function [Kmat, Mmat, Gmat] = generateBodyMatrices3D(material,Nodes,elist,bodyID)

% This function generates global stiffness, mass and gyroscopic matrices
% for a single body

numOfNodes = size(Nodes,1);
numOfDofs = 3*numOfNodes;
numOfElements = size(elist,1);

% Allocating empty sparse matrices
Kmat = spalloc(numOfDofs,numOfDofs,0);
Mmat = spalloc(numOfDofs,numOfDofs,0);
Gmat = spalloc(numOfDofs,numOfDofs,0);

% Empty vector for element volumes
Vmesh = zeros(numOfElements,1);

globalMatrixAssemblyStartTime = now;
% h  = waitbar(0,['Assembling global matrices for body ' num2str(bodyID)]);
disp(['Assembling global matrices for body ' num2str(bodyID) ' ...'])

for nn = 1:numOfElements
    tic
    %disp(['Assembling element ' num2str(nn) '/' num2str(numOfElements)])
    % waitbar(nn/numOfElements)
    
    elementNodes = elist(nn,2:end);
    
    NodalCoordinates = Nodes(elementNodes,2:4);
    
    % Detecting element type used
    if length(elementNodes) == 8 % hex8 element
        ke = hex8Kmat(material,NodalCoordinates);
        me = hex8Mmat(material,NodalCoordinates);
        ge = hex8Gmat(material,NodalCoordinates);
        Ve = hex8Volume(NodalCoordinates);
        
    elseif length(elementNodes) == 10 % tet10 element
        ke = tet10Kmat(material,NodalCoordinates);
        me = tet10Mmat(material,NodalCoordinates);
        ge = tet10Gmat(material,NodalCoordinates);
        Ve = tet10Volume(NodalCoordinates);
        
    elseif length(elementNodes) == 20 % hex20 element
        ke = hex20Kmat(material,NodalCoordinates);
        me = hex20Mmat(material,NodalCoordinates);
        ge = hex20Gmat(material,NodalCoordinates);
        Ve = hex20Volume(NodalCoordinates);
        
    else
        disp('Element type was not detected successfully.')
    end
    
    Kmat = Kmat +assembleGlobalMatrix3D_dev(ke,elementNodes,numOfDofs);
    
    Mmat = Mmat +assembleGlobalMatrix3D_dev(me,elementNodes,numOfDofs);
    
    Gmat = Gmat +assembleGlobalMatrix3D_dev(ge,elementNodes,numOfDofs);
    
    Vmesh(nn) = Ve;
end

% delete(h)
meshingEndTime = now -globalMatrixAssemblyStartTime;
disp(['Global matrices assembly completed for body ' num2str(bodyID)])
disp(['Global matrices assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
