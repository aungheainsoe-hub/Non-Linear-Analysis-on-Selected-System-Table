function [Kmat, Mmat, Gmat] = generateAllBodiesGlobalMatrices(material,Nodes,elist)

% This function generates global matrices for individual bodies and returns
% fully assembled global matrices

for bodyID = 1:size(elist.body,2)
    if bodyID  == 1 % no need to spalloc Kmat, Mmat and Gmat
        [Kmat, Mmat, Gmat] = generateBodyMatrices3D(material,Nodes,elist.body{bodyID},bodyID);
    else
        [KmatN, MmatN, GmatN] = generateBodyMatrices3D(material,Nodes,elist.body{bodyID},bodyID);
        Kmat = Kmat +KmatN;
        Mmat = Mmat +MmatN;
        Gmat = Gmat +GmatN;
    end
end
