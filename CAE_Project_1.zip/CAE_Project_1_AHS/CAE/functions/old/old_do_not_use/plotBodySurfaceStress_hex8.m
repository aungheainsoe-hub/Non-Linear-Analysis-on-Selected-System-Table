function plotBodySurfaceStress_hex8(Nodes,elist,stressVec)

% This function is plotting 3D surface of FE mesh using hex8 element

numOfElements = size(elist,1);

numOfContourColors = 10;
colorMat = colormap(jet(numOfContourColors));
mappedStressContour = linspace(min(stressVec),max(stressVec),numOfContourColors);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    
    elementStress = stressVec(elist(nn,1));
    
    [~, mappedStressContourID] = sort(abs(mappedStressContour-elementStress));
    surfColor = colorMat(mappedStressContourID(1),:);
    
    ncoord = Nodes(elementNodes([2 1 4 3]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([1 2 6 5]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([2 3 7 6]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([3 4 8 7]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([4 1 5 8]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
    ncoord = Nodes(elementNodes([5 6 7 8]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),surfColor)
    
end
