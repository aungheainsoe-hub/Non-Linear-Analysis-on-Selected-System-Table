function plotBodyWireframe_hex8(Nodes,elist)

% This function is plotting 3D wireframe of FE mesh using hex8 element

numOfElements = size(elist,1);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    ncoord = Nodes(elementNodes,2:4);
    
    plot3(ncoord([1 2],1),ncoord([1 2],2),ncoord([1 2],3),'b-')
    plot3(ncoord([2 3],1),ncoord([2 3],2),ncoord([2 3],3),'b-')
    plot3(ncoord([3 4],1),ncoord([3 4],2),ncoord([3 4],3),'b-')
    plot3(ncoord([4 1],1),ncoord([4 1],2),ncoord([4 1],3),'b-')
    plot3(ncoord([5 6],1),ncoord([5 6],2),ncoord([5 6],3),'b-')
    plot3(ncoord([6 7],1),ncoord([6 7],2),ncoord([6 7],3),'b-')
    plot3(ncoord([7 8],1),ncoord([7 8],2),ncoord([7 8],3),'b-')
    plot3(ncoord([8 5],1),ncoord([8 5],2),ncoord([8 5],3),'b-')
    plot3(ncoord([1 5],1),ncoord([1 5],2),ncoord([1 5],3),'b-')
    plot3(ncoord([2 6],1),ncoord([2 6],2),ncoord([2 6],3),'b-')
    plot3(ncoord([3 7],1),ncoord([3 7],2),ncoord([3 7],3),'b-')
    plot3(ncoord([4 8],1),ncoord([4 8],2),ncoord([4 8],3),'b-')
    
end
