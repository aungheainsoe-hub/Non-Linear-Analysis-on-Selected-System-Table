function addQuiver3CylindricalCOS()

% This function visualizes cylindrical coordinates system and presents the
% position of origo

axis equal

currentFigureMaxDimension = max(abs([diff(xlim) diff(ylim) diff(zlim)]));

arrowLength = 0.2*currentFigureMaxDimension;

quiver3(zeros(3,1),zeros(3,1),zeros(3,1),[arrowLength;0;0],[0;arrowLength;0],[0;0;0])

arrowRadius = arrowLength/2;
numOfPoints = 100;
angle = linspace(0,pi/2,numOfPoints);
x = zeros(numOfPoints,1);
y = arrowRadius*cos(angle);
z = arrowRadius*sin(angle);
line(x,y,z)

% this almost works
% quiver3(zeros(3,1),[0;0;0],zeros(3,1),zeros(3,1),[0;-arrowRadius;0],zeros(3,1))

% quiver3(zeros(3,1),[0;0;0],zeros(3,1)+[0.1;0;0],...
%     [0;0;0],0*[0;-arrowRadius;0],[0;0;0]+[0.1;0;0])

% plot3(0,0,0.1,'b*') % this doesn't appear in correct positition

text(arrowLength,0,0,'Z')
text(0,arrowLength,0,'X')
text(-arrowRadius*0.1,0,arrowRadius*1.1,'Y')
axis equal

view(131,24)
