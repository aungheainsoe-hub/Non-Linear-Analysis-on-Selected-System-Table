function foundNodes = searchNodesBasedOnCoordinates(Nodes,nSC,COS,searchType)

% This function searches nodes based on user defined coordinates

% Converting search tolerances to search limits, if used
% [X (+/-)X] --> [X_min X_max] etc.
% The limit option is always used in the actual node search routine
if strcmpi(searchType,'tolerance')
    nSC = [nSC(1)-nSC(2) nSC(1)+nSC(2) nSC(3)-nSC(4) nSC(3)+nSC(4)...
        nSC(5)-nSC(6) nSC(5)+nSC(6)];
    
elseif ~strcmpi(searchType,'limits')
    disp('Undefined coordinate system')
end

if strcmpi(COS,'cartesian')
    foundNodes = searchNodesCartesian(Nodes,nSC);
    
elseif strcmpi(COS,'cylindrical')
    foundNodes = searchNodesCylindrical(Nodes,nSC);
    
else
    disp('Undefined coordinate system')
end


function foundNodes = searchNodesCartesian(Nodes,nSC)

% This function searches nodes based on coordinates and given min-max
% interval.
% 
% nodeSearchCoordinates = [X_min X_max Y_min Y_max Z_min Z_max];
% 
% Nodes = [NodeID X-coord Y-coord Z-coord];

foundNodes = [];

for nn = 1:size(Nodes,1)
    if (nSC(1) < Nodes(nn,2) && Nodes(nn,2) < nSC(2)) && ...
            (nSC(3) < Nodes(nn,3) && Nodes(nn,3) < nSC(4)) && ...
            (nSC(5) < Nodes(nn,4) && Nodes(nn,4) < nSC(6))
        foundNodes = [foundNodes; Nodes(nn,1)];
    end
end


function foundNodes = searchNodesCylindrical(Nodes,nSC)

foundNodes = [];

% Axis of rotation is required to be around global X-axis

% Converting cartesian coordinates to cylindrical coordinates
Nodes = [Nodes(:,1) sqrt(Nodes(:,3).^2+Nodes(:,4).^2) zeros(size(Nodes,1),1) Nodes(:,2)];

for nn = 1:size(Nodes,1)
    if (nSC(1) < Nodes(nn,2) && Nodes(nn,2) < nSC(2)) && ...
            (nSC(5) < Nodes(nn,4) && Nodes(nn,4) < nSC(6))
        foundNodes = [foundNodes; Nodes(nn,1)];
    end
end
