function F_deltaT_Vec = calculateGlobal_deltaT_Vec(material,Nodes,elist,NodalTemperatureVec)

% This function calculates element centrifugal force vectors for full
% assembly

numOfDofs = 3*size(Nodes,1);

F_deltaT_Vec = zeros(numOfDofs,1);

fprintf('Assembling global F deltaT Vec for body ');

globalMatrixAssemblyStartTime = now;

% Loop for calculating element centrifugal force vector
for bodyID = 1:size(elist.body,2)
    
    % h  = waitbar(0,['Assembling global F deltaT Vec for body ' num2str(bodyID)]);
    %disp(['Assembling global F deltaT Vec for body ' num2str(bodyID) ' ...'])
    
    if bodyID == 1
        fprintf('%d',bodyID);
    else
        fprintf(', %d',bodyID);
    end
    
    elistBodyN = elist.body{bodyID};
    
    numOfElements = size(elistBodyN,1);
    
    for nn = 1:numOfElements
        
        % waitbar(nn/numOfElements)
        
        elementNodes = elistBodyN(nn,2:end);
        NodalCoordinates = Nodes(elementNodes,2:4);
        
        elementNodal_deltaT = NodalTemperatureVec(elementNodes);
        
        if length(elementNodes) == 8 % hex8 element
            F_deltaT_ElementVec = hex8F_deltaT_Vec(material(bodyID),NodalCoordinates,elementNodal_deltaT);
            
        elseif length(elementNodes) == 10 % tet10 element
            F_deltaT_ElementVec = tet10F_deltaT_Vec(material(bodyID),NodalCoordinates,elementNodal_deltaT);
            
        elseif length(elementNodes) == 20 % hex20 element
            F_deltaT_ElementVec = hex20F_deltaT_Vec(material(bodyID),NodalCoordinates,elementNodal_deltaT);
            
        else
            disp('Unknown element type')
        end
        
        F_deltaT_Vec = F_deltaT_Vec +assembleGlobalForceVector(F_deltaT_ElementVec,elementNodes,numOfDofs);
    end
    
    % delete(h)
end

meshingEndTime = now -globalMatrixAssemblyStartTime;
fprintf('\n');
disp(['Global F_deltaT_Vec assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
