function plotConstraintNodes(Nodes,elist,foundNodes,COStype)

% This function plots constraint nodes

% Plotting wireframe of the body
figure
hold on
plotBodyWireframe3D(Nodes,elist)

% Plotting constraint nodes
for nn = 1:length(foundNodes)
    plot3(Nodes(foundNodes(nn),2),Nodes(foundNodes(nn),3),Nodes(foundNodes(nn),4),'r*')
end

if strcmpi(COStype,'cartesian')
    addQuiver3()
elseif strcmpi(COStype,'cylindrical')
    addQuiver3CylindricalCOS()
else
    disp('Undefined coordinate system')
end
