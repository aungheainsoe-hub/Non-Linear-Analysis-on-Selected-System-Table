function plotBodyWireframe3D(Nodes,elist)

% This function is plotting 3D wireframe of FE mesh

% Detecting element type used
elementNodes = size(elist,2);

if elementNodes == 9 % hex8 element
    plotBodyWireframe_hex8(Nodes,elist)
    
elseif elementNodes == 11 % tet10 element
    plotBodyWireframe_tet10(Nodes,elist)
    
elseif elementNodes == 21 % hex20 element
    plotBodyWireframe_hex20(Nodes,elist)
    
else
    disp('Element type was not detected successfully.')
end
