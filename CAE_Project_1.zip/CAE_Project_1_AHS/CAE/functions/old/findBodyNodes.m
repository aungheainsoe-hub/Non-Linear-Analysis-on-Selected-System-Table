function bodyNodes = findBodyNodes(elist)

% This function returns all nodes which a particular body contains

% Removing element number column
elist = elist(:,2:end);

% Sorting node numbers
elist = sort(elist(:));

% Adding the first node
bodyNodes = elist(1);

for nn = 2:length(elist)
    if elist(nn) ~= bodyNodes(end)
        bodyNodes(end+1) = elist(nn);
    end
end
