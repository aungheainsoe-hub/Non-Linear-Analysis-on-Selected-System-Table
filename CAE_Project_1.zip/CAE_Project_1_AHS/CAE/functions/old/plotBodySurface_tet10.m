function plotBodySurface_tet10(Nodes,elist)

% This function is plotting 3D surface of FE mesh using tet10 element

numOfElements = size(elist,1);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    
    ncoord = Nodes(elementNodes([2 5 1 7 3 6]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([1 5 2 9 4 8]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([2 6 3 10 4 9]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([3 7 1 8 4 10]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
end
