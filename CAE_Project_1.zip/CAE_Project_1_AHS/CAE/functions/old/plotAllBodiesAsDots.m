function plotAllBodiesAsDots(Nodes,elist)

% This function plots every single body on an assembly

numOfBodies = size(elist.body,2);

numOfPlotWindows = ceil(numOfBodies/6);

for nPlotWindow = 1:numOfPlotWindows
    
    figure
    
    nSubplot = 0;
    for bodyID = (nPlotWindow-1)*6+1:(nPlotWindow-1)*6+6
        
        if bodyID > numOfBodies
            break
        end
        
        try % using try-catch method to cut the nonexisting bodies
            nSubplot = nSubplot+1;
            subplot(2,3,nSubplot)
            hold on
            bodyElist = elist.body{bodyID};
            bodyNodeList = unique(bodyElist(:,2:end));
            for nn = 1:length(bodyNodeList)
                plot3(Nodes(bodyNodeList(nn),2),Nodes(bodyNodeList(nn),3),...
                    Nodes(bodyNodeList(nn),4),'b.')
            end
            title(['Body ' num2str(bodyID)])
            addQuiver3()
            
        catch
            continue
        end
    end
end
