function plotBodySurface_hex20(Nodes,elist)

% This function is plotting 3D surface of FE mesh using hex20 element

numOfElements = size(elist,1);

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    
    ncoord = Nodes(elementNodes([2 9 1 12 4 11 3 10]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([1 9 2 18 6 13 5 17]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([2 10 3 19 7 14 6 18]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([3 11 4 20 8 15 7 19]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([4 12 1 17 5 16 8 20]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
    ncoord = Nodes(elementNodes([5 13 6 14 7 15 8 16]),:);
    fill3(ncoord(:,2),ncoord(:,3),ncoord(:,4),'c')
    
end
