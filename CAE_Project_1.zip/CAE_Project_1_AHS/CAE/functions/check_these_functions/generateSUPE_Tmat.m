function [Tmat_Ord, Tmat_SUPE] = generateSUPE_Tmat(Kmat,Mmat,globalBoundaryDofs,eigenmodes)

% This function generates superelement using Craig-Bampton dynamic model
% reduction
%
% Inputs:
% - Kmat               - global or body stiffness matrix
% - Mmat               - global or body mass matrix
% - globalBoundaryDofs - column vector of boundary nodes
% - eigenmodes         - vector of eigenmodes

numOfDofs = size(Kmat,1);

% reordering the global dofs
DofOrder = 1:numOfDofs;
for nn = length(globalBoundaryDofs):-1:1
    DofOrder(DofOrder==globalBoundaryDofs(nn)) = [];
end
DofOrder = [DofOrder globalBoundaryDofs'];

% global internal-boundary dof reordering matrix
Tmat_Ord = speye(numOfDofs);
Tmat_Ord = Tmat_Ord(:,DofOrder);

% reordering stiffness and mass matrices
Kmat_Ordered = Tmat_Ord'*Kmat*Tmat_Ord;
clear Kmat
Mmat_Ordered = Tmat_Ord'*Mmat*Tmat_Ord;
clear Mmat

% lists of internal and boundary dofs
internalDofs = 1:numOfDofs-length(globalBoundaryDofs);
boundaryDofs = length(internalDofs)+1:numOfDofs;

Kmat_ii = Kmat_Ordered(internalDofs,internalDofs);
Mmat_ii = Kmat_Ordered(internalDofs,internalDofs);
Kmat_ib = Kmat_Ordered(internalDofs,boundaryDofs);

Phimat = -Kmat_ii\Kmat_ib;

if length(eigenmodes) > 0
    % Solving eigenvalue problem
    [FiiN, D] = eigs(Kmat_ii,Mmat_ii,max(eigenmodes),'sm');
    [Freq, indx] = sort(real(sqrt(diag(D)))/(2*pi));
    FiiN = FiiN(:,indx);
    FiiN = FiiN(:,eigenmodes);
else
    FiiN = [];
end

% Making superlement transformation matrix
zeros_SUPE = zeros(length(boundaryDofs),length(eigenmodes));
eye_SUPE = eye(length(boundaryDofs));

Tmat_SUPE = [FiiN       Phimat
             zeros_SUPE eye_SUPE];
%
