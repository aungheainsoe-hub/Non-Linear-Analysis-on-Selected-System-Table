function KGmat = calculateAssemblyStressStiffeningMat(Nodes,elist,stressMat)

% This function calculated global stress stiffening matrix

numOfDofs = 3*size(Nodes,1);
numOfElements = size(elist,1);

% Allocating list for cell of element stress stiffening matrices
KGmat_MNX = zeros(1200*numOfElements,3); % hex20 kgmat has 1200 NNZs
KGmat_Cells = 0; % total number of NNZ stress stiffnening cells

fprintf('Assembling global stress stiffening matrix for body ');

globalMatrixAssemblyStartTime = now;
% KGmat_timeVec = []; %#-----------------------------------------------------
for bodyID = 1:size(elist.body,2)
    
    % h  = waitbar(0,['Assembling global stress stiffening matrix for body ' num2str(bodyID)]);
    %disp(['Assembling global stress stiffening matrix for body ' num2str(bodyID) ' ...'])
    
    if bodyID == 1
        fprintf('%d',bodyID);
    else
        fprintf(', %d',bodyID);
    end
    
    elistBodyN = elist.body{bodyID};
    numOfElements = size(elistBodyN,1);
    
    for nn = 1:numOfElements
        
        % waitbar(nn/numOfElements)
        ElementID = elistBodyN(nn,1);
        elementNodes = elistBodyN(nn,2:end);
        NodalCoordinates = Nodes(elementNodes,2:4);
        stressVec = stressMat(:,ElementID);
        
        if size(NodalCoordinates,1) == 8 % hex8 element
            kgmat = hex8KGmat(NodalCoordinates,stressVec);
            
        elseif size(NodalCoordinates,1) == 10 % tet10 element
            kgmat = tet10KGmat(NodalCoordinates,stressVec);
            
        elseif size(NodalCoordinates,1) == 20 % hex20 element
            kgmat = hex20KGmat(NodalCoordinates,stressVec);
            
        else
            disp('Unknown element type')
        end
        
        [KGmat_MNX, KGmat_Cells] = assembleGlobalMatrix3D(kgmat,elementNodes,KGmat_MNX,KGmat_Cells);
        
    end
    
end


KGmat_M = KGmat_MNX(:,1);
KGmat_N = KGmat_MNX(:,2);
KGmat_X = KGmat_MNX(:,3);
clear KGmat_MNX

KGmat_M(KGmat_M == 0) = [];
KGmat_N(KGmat_N == 0) = [];
KGmat_X(KGmat_X == 0) = [];
KGmat_nn = max([max(KGmat_M) max(KGmat_N)]);

KGmat = sparse(KGmat_M,KGmat_N,KGmat_X,KGmat_nn,KGmat_nn);


% Expanding single body matrices to take into account all global DOFs
if size(KGmat,1) < numOfDofs
    KGmat(numOfDofs,numOfDofs) = 0;
end


% figure,plot(KGmat_timeVec)%#-----------------------------------------------
% sum(KGmat_timeVec) %# -----------------------------------------------------

meshingEndTime = now -globalMatrixAssemblyStartTime;
fprintf('\n');
disp(['Global stress stiffening matrix assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])

