function dofs = nodesToDofs(nodes)

dofs = zeros(3*length(nodes),1);

for nn = 1:length(nodes)
    dofs(3*nn-2:3*nn,1) = 3*nodes(nn)-2:3*nodes(nn);
end
