
function plotEigenModeAsSurfaceNodes(Nodes,elist,Freq,FiiN,surfaceNodes,modeN)

% This function plots eigen mode using surface nodes only

FiiN_modeN = real(FiiN(:,modeN));

uMat = reshape(FiiN_modeN,3,size(Nodes,1))';

% Automatic deformation factor
NodesMax = max(max(abs(Nodes(:,2:4))));
defFactor = 0.10*NodesMax/max(abs(uMat(:)));
if defFactor > 1e9
    defFactor = 1;
end

deformedPosition = Nodes+[zeros(size(Nodes,1),1) defFactor*uMat];

tet4Nodes = [];
for nn = 1:length(elist.body)
    bodyNelements = elist.body{nn}(:,2:5);
    tet4Nodes = [tet4Nodes; unique(bodyNelements(:))];
end


figure
hold on

for nn = 1:length(surfaceNodes)
    if sum(surfaceNodes(nn) == tet4Nodes) == 1
        plot3(deformedPosition(surfaceNodes(nn),2),deformedPosition(surfaceNodes(nn),3),deformedPosition(surfaceNodes(nn),4),'b.')
    end
end

title(['Eigenmode ' num2str(modeN) ', ' num2str(Freq(modeN)) ' Hz'])

addQuiver3
