function plotCampbell(input,lowestModes)

% This function calculated damped eigevalues of damped eigenproblem and
% plots a Campbell diagram using modal reduced matrices

% Solve eigenmodes and eigenfrequencies
[~, FiiN] = solveEigenModes(input.Kmat,input.Mmat,lowestModes);

% Performing modal reduction for full matrices
[KmatMR, MmatMR, CmatMR, GmatMR, ~] = modalReduction_KMCG(input,FiiN,lowestModes);

% Creating zero and identity matrices
zerosMR = zeros(lowestModes);
eyeMR = eye(lowestModes);

% Matrix for storing speed step results
Freq_mat = zeros(lowestModes,length(input.speedVec));

% Opening waitbar
% h = waitbar(0,'Computing Campbell diagram...');
disp('Computing Campbell diagram...')

% Speed loop
for nn = 1:length(input.speedVec)
    
    % Forming modal state space matrix
    AA = [zerosMR           eyeMR
          -MmatMR\KmatMR -MmatMR\(CmatMR+input.speedVec(nn)*GmatMR)];
    %
    
    % Solution of state space matrix eigenvalues
    [~, d] = eig(AA);
    
    % Sorting modes based on frequency
    [Freq, ~] = sort(diag(d));
    
    % Storing speed step results
    Freq_mat(:,nn) = Freq(1:2:end);
    
    % Updating waitbar
    % waitbar(nn/length(input.speedVec))
    disp(['Campbell diagram progress ' num2str(100*nn/length(input.speedVec)) ' %'])
    
end

% Closing waitbar
% delete(h)
disp('Computing Campbell diagram done')

% Plotting Campbell diagram
figure
hold on

% for nn = 1:size(Freq_mat,2)-1
%     plot(input.speedVec(nn:nn+1)/2/pi*60,...
%         sqrt(real(Freq_mat(:,nn:nn+1)).^2+imag(Freq_mat(:,nn:nn+1)).^2)/2/pi,'b')
% end
for nn = 1:size(Freq_mat,2)-1
    plot(input.speedVec(nn:nn+1)/2/pi*60,...
        abs(imag(Freq_mat(:,nn:nn+1)))/2/pi,'b')
end

plot(input.speedVec/2/pi*60,input.speedVec/2/pi,'k--')
grid
xlabel('Spin speed (RPM)')
ylabel('Frequency (Hz)')
title('Campbell diagram')

ylim([0 1.5*input.speedVec(end)/2/pi])



function [KmatMR, MmatMR, CmatMR, GmatMR, FiiNormN] = modalReduction_KMCG(input,FiiN,lowestModes)

% This functions performs modal reduction for stiffness, mass, damping and
% gyroscopic matrices

% Mass normalization
FiiNormN = zeros(size(FiiN,1),lowestModes);

for nMode = 1:lowestModes
    FiiNormN(:,nMode) = FiiN(:,nMode)/sqrt(FiiN(:,nMode)'...
        *input.Mmat*FiiN(:,nMode));
end

% Modal matrices
KmatMR = FiiNormN'*input.Kmat*FiiNormN;
MmatMR = FiiNormN'*input.Mmat*FiiNormN;
CmatMR = FiiNormN'*input.Cmat*FiiNormN;
GmatMR = FiiNormN'*input.Gmat*FiiNormN;

