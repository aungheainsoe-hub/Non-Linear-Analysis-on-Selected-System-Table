function Kmat = addSpringsBetweenNodes_3D(Kmat,nodes1,nodes2,kVec,logicVec)

% This function adds spring coefficients to stiffness matrix between
% two nodes. nodes1 and nodes2 vectors has to have the same length.
% The spring vector kVec has stiffness terms for all dofs UX, UY, UZ for
% one single node.

% kVec = [kb_x kb_y kb_z];

% logicVec has terms of 0 and 1. This vector content determines which nodes
% are still closed and require the spring contraints.

numOfFoundNodes = length(nodes1);

for nn = 1:numOfFoundNodes
    
    if logicVec(nn) == 1
        
        % Source node
        Kmat(3*nodes1(nn)-2:3*nodes1(nn),3*nodes1(nn)-2:3*nodes1(nn)) = ...
            Kmat(3*nodes1(nn)-2:3*nodes1(nn),3*nodes1(nn)-2:3*nodes1(nn)) ...
            +diag(kVec/numOfFoundNodes);
        
        % Target node
        Kmat(3*nodes2(nn)-2:3*nodes2(nn),3*nodes2(nn)-2:3*nodes2(nn)) = ...
            Kmat(3*nodes2(nn)-2:3*nodes2(nn),3*nodes2(nn)-2:3*nodes2(nn)) ...
            +diag(kVec/numOfFoundNodes);
        
        % Cross coupling source-to-target
        Kmat(3*nodes1(nn)-2:3*nodes1(nn),3*nodes2(nn)-2:3*nodes2(nn)) = ...
            Kmat(3*nodes1(nn)-2:3*nodes1(nn),3*nodes2(nn)-2:3*nodes2(nn)) ...
            -diag(kVec/numOfFoundNodes);
        
        % Cross coupling target-to-source
        % Source node
        Kmat(3*nodes2(nn)-2:3*nodes2(nn),3*nodes1(nn)-2:3*nodes1(nn)) = ...
            Kmat(3*nodes2(nn)-2:3*nodes2(nn),3*nodes1(nn)-2:3*nodes1(nn)) ...
            -diag(kVec/numOfFoundNodes);
    end
end
