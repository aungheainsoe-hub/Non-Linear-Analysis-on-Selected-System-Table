function addQuiver3()

% This function visualizes cartesian coordinates system and presents the
% position of origo

axis equal

currentFigureMaxDimension = max(abs([diff(xlim) diff(ylim) diff(zlim)]));

xlabel('X (m)')
ylabel('Y (m)')
zlabel('Z (m)')

arrowLength = 0.2*currentFigureMaxDimension;
quiver3(zeros(3,1),zeros(3,1),zeros(3,1),[arrowLength;0;0],[0;arrowLength;0],[0;0;arrowLength])
text(arrowLength,0,0,'X')
text(0,arrowLength,0,'Y')
text(0,0,arrowLength,'Z')

view(131,24)

% axis equal
