function [Nodes, elist] = readANSYSinputFile(inputFile)

% This function extracts node coordinate list and element list with proper
% node order from ANSYS input file.
%
% format: Nodes = [nodeID X-coord Y-coord Z-coord]
%
% format: elist.body{n} = [elementID [node1..nodeN]]

fileHandle = fopen(inputFile, 'r');

while 1
    line = fgets(fileHandle);
    if strncmpi(line,'/com,*********** Nodes for the whole assembly',45)
        break
    end
end

line = fgets(fileHandle);
line = strsplit(line,',');
numOfNodesGUESS = str2num(line{end});
line = fgets(fileHandle);

Nodes = zeros(numOfNodesGUESS,4);

nodeN = 0;
while 1
    line = fgets(fileHandle);
    
    if strncmpi(line,'-1',2)
        break
    end
    
    nodeN = nodeN+1;
    Nodes(nodeN,1:4) = str2num(line);
end

Nodes(nodeN+1:numOfNodesGUESS,:) = [];



breakNow = 0;
bodyID = 0;
while 1
    if breakNow == 1
        break
    end
    
    while 1
        
        line = fgets(fileHandle);
        
        if line == -1
            breakNow = 1;
            break
        end
        
        if strncmpi(line,'/com,*********** Elements for Body',34)
            bodyID = bodyID+1;
            
            line = fgets(fileHandle);
            line = fgets(fileHandle);
            line = strsplit(line,',');
            numOfElements = str2num(line{end});
            
            elist.body{bodyID} = zeros(numOfElements,11);
            
            line = fgets(fileHandle);
            
            for nn = 1:numOfElements
                line1 = str2num(fgets(fileHandle));
                line2 = str2num(fgets(fileHandle));
                
                elist.body{bodyID}(nn,:) = [line1(11:end) line2];
            end
            
            break
        end
    end  
end

fclose(fileHandle);

