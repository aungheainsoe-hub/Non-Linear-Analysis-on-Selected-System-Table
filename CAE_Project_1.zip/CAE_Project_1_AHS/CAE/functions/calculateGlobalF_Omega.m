function F_OmegaVec = calculateGlobalF_Omega(material,Nodes,elist)

% This function calculates element centrifugal force vectors for full
% assembly

numOfDofs = 3*size(Nodes,1);

F_OmegaVec = zeros(numOfDofs,1);

fprintf('Assembling global F_OmegaVec for body ');

globalMatrixAssemblyStartTime = now;

% Loop for calculating element centrifugal force vector
for bodyID = 1:size(elist.body,2)
    
    % h  = waitbar(0,['Assembling global F OmegaVec for body ' num2str(bodyID)]);
    %disp(['Assembling global F OmegaVec for body ' num2str(bodyID) ' ...'])
    
    if bodyID == 1
        fprintf('%d',bodyID);
    else
        fprintf(', %d',bodyID);
    end
    
    elistBodyN = elist.body{bodyID};
    
    numOfElements = size(elistBodyN,1);
    
    for nn = 1:numOfElements
        
        % waitbar(nn/numOfElements)
        
        elementNodes = elistBodyN(nn,2:end);
        NodalCoordinates = Nodes(elementNodes,2:4);
        
        if length(elementNodes) == 10 % tet10 element
            F_OmegaElementVec = tet10F_OmegaVec(material(bodyID),NodalCoordinates);
            
        else
            disp('Unknown element type')
        end
        
        F_OmegaVec = F_OmegaVec +assembleGlobalForceVector(F_OmegaElementVec,elementNodes,numOfDofs);
    end
    
    % delete(h)
end

meshingEndTime = now -globalMatrixAssemblyStartTime;
fprintf('\n');
disp(['Global F_OmegaVec assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
