
function F_Vec = generateGlobalBodyFvec(material,Nodes,elist,bodyID,vectorType,info)

% This function calculates element gravity force vectors for full
% assembly

numOfDofs = 3*size(Nodes,1);
numOfElements = size(elist,1);

F_Vec = zeros(numOfDofs,1);

disp(['Assembling global ' vectorType ' for body ' num2str(bodyID)]);

globalMatrixAssemblyStartTime = now;

for nn = 1:numOfElements
    
    elementNodes = elist(nn,2:end);
    NodalCoordinates = Nodes(elementNodes,2:4);
    
    if strcmpi(vectorType,'F_gravity')
        accelerationVec = info;
        F_vector = tet10F_gravityVec(material,NodalCoordinates,accelerationVec);
        
    elseif strcmpi(vectorType,'F_Omega')
        F_vector = tet10F_OmegaVec(material,NodalCoordinates);
        
    elseif strcmpi(vectorType,'F_deltaT')
        NodalTemperatureVec = info;
        elementNodal_deltaT = NodalTemperatureVec(elementNodes);
        F_vector = tet10F_deltaT_Vec(material,NodalCoordinates,elementNodal_deltaT);
        
    else
        disp('Unknown vector type')
    end
    
    F_Vec = F_Vec +assembleGlobalForceVector(F_vector,elementNodes,numOfDofs);
end

meshingEndTime = now -globalMatrixAssemblyStartTime;

disp(['Global ' vectorType ' vecotr assembly completed for body ' num2str(bodyID)])
disp(['Global ' vectorType ' assembly duration: ' num2str(round(meshingEndTime*24*36000)/10) ' s'])
