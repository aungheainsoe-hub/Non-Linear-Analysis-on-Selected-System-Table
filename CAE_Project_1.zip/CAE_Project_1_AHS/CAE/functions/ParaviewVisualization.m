function ParaviewVisualization(Nodes,Umat,elist,fileName,nodalResultData,legendTitle)

% This function creates paraview compatible visualization file

numOfNodes = size(Nodes,1);

fileHandle = fopen(fileName, 'w');

% Writing file heading
fprintf(fileHandle,'# vtk DataFile Version 3.0\n');
fprintf(fileHandle,'\n');
fprintf(fileHandle,'ASCII\n');
fprintf(fileHandle,'\n');
fprintf(fileHandle,'DATASET UNSTRUCTURED_GRID\n');

% Writing points definition
fprintf(fileHandle,'POINTS %d float\n',numOfNodes);

% Writing nodes
for nn = 1:numOfNodes
    fprintf(fileHandle,'%s\n',num2str(Nodes(nn,2:4)+Umat(nn,2:4)));
end
% HERE NODES+UMAT %#-------------------------------------------------------

% Number of all elements
allElements = 0;

% List of matlab and paraview element types
elementTypesMatlab = [];
elementTypesParaview = [];

% Number of all element nodes, not the same than num of all mesh nodes
allElementNodes = 0;

for bodyID = 1:size(elist.body,2)
    
    allElements = allElements +size(elist.body{bodyID},1);
    
    if size(elist.body{bodyID},2) == 9
        elementTypesMatlab = [elementTypesMatlab; 8];
        elementTypesParaview = [elementTypesParaview; 12]; % paraview hex8
        
    elseif size(elist.body{bodyID},2) == 11
        elementTypesMatlab = [elementTypesMatlab; 10];
        elementTypesParaview = [elementTypesParaview; 24]; % paraview tet10
        
    elseif size(elist.body{bodyID},2) == 21
        elementTypesMatlab = [elementTypesMatlab; 20];
        elementTypesParaview = [elementTypesParaview; 25]; % paraview hex20
    else
        disp('Unknown element type')
    end
    
    allElementNodes = allElementNodes ...
        +size(elist.body{bodyID},2)*size(elist.body{bodyID},1);
end

% Writing cells definition
fprintf(fileHandle,'CELLS %d %d\n',allElements,allElementNodes);

% Writing element type and element nodes
for bodyID = 1:size(elist.body,2)
    
    elistBodyN = elist.body{bodyID};
    numOfElements = size(elistBodyN,1);
    
    for nElement = 1:numOfElements
        
        elementNodes = elistBodyN(nElement,2:end);
        
        % Note here "elementNodes-1" in Paraview first number is zero
        fprintf(fileHandle,'%d %s\n',elementTypesMatlab(bodyID),num2str(elementNodes-1));
    end
end

% Writing cell types definition
fprintf(fileHandle,'CELL_TYPES %d\n',allElements);

% Writing cell types
for bodyID = 1:size(elist.body,2)
    
    for nElementType = 1:size(elist.body{bodyID},1)
        
        fprintf(fileHandle,'%d\n',elementTypesParaview(bodyID));
    end
end

% Writing nodal results data definition
fprintf(fileHandle,'POINT_DATA %d\n',numOfNodes);
fprintf(fileHandle,'SCALARS %s float 1\n',legendTitle);
fprintf(fileHandle,'LOOKUP_TABLE default\n');

% Writing nodal results data
for nn = 1:numOfNodes
    
    fprintf(fileHandle,'%d\n',nodalResultData(nn));
end

fclose(fileHandle);
