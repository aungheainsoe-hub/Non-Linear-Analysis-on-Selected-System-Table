function stressMat = calculateAssemblyStress(material,Nodes,elist,Uvec)

% This function calculates element stress vectors for full assembly

% Calculating number of elements
numOfElements = 0;
for bodyID = 1:size(elist.body,2)
    numOfElements = numOfElements +length(elist.body{bodyID});
end

% Storing stress vector into matrix form
stressMat = zeros(6,numOfElements);

% Loop for calculating element stresses
for bodyID = 1:size(elist.body,2)
    
    elistBodyN = elist.body{bodyID};
    
    for nn = 1:size(elistBodyN,1)
        
        ElementID = elistBodyN(nn,1);
        elementNodes = elistBodyN(nn,2:end);
        NodalCoordinates = Nodes(elementNodes,2:4);
        uElement = zeros(3*length(elementNodes),1);
        
        for nodeN = 1:length(elementNodes)
            
            uElement(3*nodeN-2:3*nodeN,1) = Uvec(3*elementNodes(nodeN)-2:3*elementNodes(nodeN));
            
        end
        
        stressMat(:,ElementID) = calculateElementStress(material(bodyID),NodalCoordinates,uElement);
    end
end
