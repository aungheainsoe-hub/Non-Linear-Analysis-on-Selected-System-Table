
function plotBodySurfaceNodes(Nodes,elist,nodesList)

% This function plots surface nodes of a single body

elist = elist(:,2:5); % selecting only the edge nodes (tet4)
elist = unique(elist);

for nn = 1:length(nodesList)
    if sum(nodesList(nn) == elist) == 1
        plot3(Nodes(nodesList(nn),2),Nodes(nodesList(nn),3),Nodes(nodesList(nn),4),'b.')
    end
end
