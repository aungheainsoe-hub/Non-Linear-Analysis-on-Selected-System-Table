function stressVec = calculateElementStress(material,NodalCoordinates,uElement)

% This function returns element stress vector

% stressVec = [sigma_x
%              sigma_y
%              sigma_x
%              tau_xy
%              tau_yz
%              tau_zx];
%

% Detecting element type used
if length(uElement) == 24 % hex8 element
    disp('hex8 element is not supported anymore')
    %stressVec = hex8Stress(material,NodalCoordinates,uElement);
    
elseif length(uElement) == 30 % tet10 element
    stressVec = tet10Stress(material,NodalCoordinates,uElement);
    
elseif length(uElement) == 60 % hex20 element
    stressVec = hex20Stress(material,NodalCoordinates,uElement);
    
else
    disp('Unknown element type')
end
