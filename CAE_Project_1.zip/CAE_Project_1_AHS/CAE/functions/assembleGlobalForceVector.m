function F_GlobalVec = assembleGlobalForceVector(F_ElementVec,elementNodes,numOfDofs)

% This function assembles global force vector

% Allocating empty full vector
F_GlobalVec = zeros(numOfDofs,1);

for nn = 1:length(elementNodes)
    
    F_GlobalVec(3*elementNodes(nn)-2:3*elementNodes(nn)) = ...
        F_ElementVec(3*nn-2:3*nn);
end
