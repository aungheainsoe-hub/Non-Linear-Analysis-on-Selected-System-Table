function  F_OmegaElementVec = tet10F_OmegaVec(material,NodalCoordinates)

% This function calculates element centrifugal force vector


% Centrifugal force vector
F_OmegaElementVec = zeros(30,1);


% wTw = [Omega']*[Omega], spin around global X-axis
wTw = [0 0 0
       0 1 0
       0 0 1];
%


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [~, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    Nmat = tet10Nmat(xi_i(nn),eta_i(nn),zeta_i(nn));
    
    for nodeID = 1:10
        
        F_OmegaElementVec(3*nodeID-2:3*nodeID) = ...
            F_OmegaElementVec(3*nodeID-2:3*nodeID) ...
            +w_i(nn)*Nmat(:,3*nodeID-2:3*nodeID)'*wTw*NodalCoordinates(nodeID,:)'*1/6*detJ;
    end
end

F_OmegaElementVec = material.rho*F_OmegaElementVec;



% % % % Centrifugal force vector
% % % F_OmegaElementVec = zeros(30,1);
% % % 
% % % % [0; dNi(2,nn)*NodalCoordinates(nn,3)^2-dNi(3,nn)*NodalCoordinates(nn,2)*NodalCoordinates(nn,3); dNi(3,nn)*NodalCoordinates(nn,2)^2-dNi(2,nn)*NodalCoordinates(nn,2)*NodalCoordinates(nn,3)]
% % % % Tetrahedron 5-point numerical integration
% % % xi_i = [1/6 0.5 1/6 1/6 0.25];
% % % eta_i = [1/6 1/6 0.5 1/6 0.25];
% % % zeta_i = [1/6 1/6 1/6 0.5 0.25];
% % % w_i = [0.45 0.45 0.45 0.45 -0.8];
% % % 
% % % for nn = 1:5
% % %     %
% % %     [~, detJ, dNi] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
% % %     
% % %     for nodeID = 1:10
% % %         
% % %         F_OmegaElementVec(3*nodeID-2:3*nodeID) = ...
% % %             F_OmegaElementVec(3*nodeID-2:3*nodeID) ...
% % %             +w_i(nn)*[0; dNi(2,nn)*NodalCoordinates(nn,3)^2-dNi(3,nn)*NodalCoordinates(nn,2)*NodalCoordinates(nn,3); dNi(3,nn)*NodalCoordinates(nn,2)^2-dNi(2,nn)*NodalCoordinates(nn,2)*NodalCoordinates(nn,3)]*1/6*detJ;
% % %     end
% % % end
% % % 
% % % F_OmegaElementVec = material.rho*F_OmegaElementVec;

