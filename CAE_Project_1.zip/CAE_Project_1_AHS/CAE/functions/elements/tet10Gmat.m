function ge = tet10Gmat(material,NodalCoordinates)

% This function calculates element gyroscopic matrix

% Gyroscopic damping matrix
ge = zeros(30);


% SPIN AXIS IS NOW SET FOR GLOBAL X-AXIS, to be expanded to support 
% arbitrary axis of rotation


if 1
% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [~, detJ, dNi] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    Nmat = tet10Nmat(xi_i(nn),eta_i(nn),zeta_i(nn));
    
    gTemp = zeros(30,3);
    for kk = 1:10
        gTemp(3*kk-2:3*kk,:) = diag(ones(3,1)*(dNi(3,kk)*NodalCoordinates(kk,2)-dNi(2,kk)*NodalCoordinates(kk,3)));
    end
    
    ge = ge +w_i(nn)*gTemp*Nmat*1/6*detJ;
    
end

ge = material.rho*(ge' -ge);
end % if

