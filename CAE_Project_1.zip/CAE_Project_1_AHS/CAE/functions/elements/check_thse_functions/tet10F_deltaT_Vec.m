function  F_deltaT_ElementVec = tet10F_deltaT_Vec(material,NodalCoordinates,elementNodal_deltaT)

% This function calculates element thermal expansion force vector

Dmat = DmatIsotropic3D(material);


% Centrifugal force vector
F_deltaT_ElementVec = zeros(30,1);


% Vector of thermal expansion coefficients
alphaVec = material.alpha*[1 1 1 0 0 0]';


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [Bmat, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    for nodeID = 1:10
        
        F_deltaT_ElementVec(3*nodeID-2:3*nodeID) = ...
            F_deltaT_ElementVec(3*nodeID-2:3*nodeID) ...
            +w_i(nn)*Bmat(:,3*nodeID-2:3*nodeID)'*Dmat*alphaVec*elementNodal_deltaT(nodeID)*1/6*detJ;
    end
end
