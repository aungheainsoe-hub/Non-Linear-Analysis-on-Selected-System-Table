function  F_gravityElementVec = tet10F_gravityVec(material,NodalCoordinates,accelerationVec)

% This function calculates element centrifugal force vector

% Centrifugal force vector
F_gravityElementVec = zeros(30,1);


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [~, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    Nmat = tet10Nmat(xi_i(nn),eta_i(nn),zeta_i(nn));
    
    for nodeID = 1:10
        
        F_gravityElementVec(3*nodeID-2:3*nodeID) = ...
            F_gravityElementVec(3*nodeID-2:3*nodeID) ...
            +w_i(nn)*Nmat(:,3*nodeID-2:3*nodeID)'*accelerationVec*1/6*detJ;
    end
end

F_gravityElementVec = material.rho*F_gravityElementVec;
