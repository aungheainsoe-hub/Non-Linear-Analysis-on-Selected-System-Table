function kgmat = tet10KGmat(NodalCoordinates,stressVec)

% This function element stress stiffening matrix

% Stress stiffening matrix
kgmat = zeros(30);

% 3x3 identity matrix
I3 = eye(3);

% Initial stress matrix
S0 = [I3*stressVec(1) I3*stressVec(4) I3*stressVec(6)
      I3*stressVec(4) I3*stressVec(2) I3*stressVec(5)
      I3*stressVec(6) I3*stressVec(5) I3*stressVec(3)];
%

% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [Bmat, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    GeMat = tet10GeMat(Bmat);
    
    kgmat = kgmat +w_i(nn)*GeMat'*S0*GeMat*1/6*detJ;
    
end


function GeMat = tet10GeMat(Bmat)

% 3x3 identity matrix
I3 = eye(3);

% Ge matrix
GeMat = zeros(9,30);

for nn = 1:10
    
    GeMat(1:3,3*nn-2:3*nn) = I3*Bmat(1,3*nn-2);
    GeMat(4:6,3*nn-2:3*nn) = I3*Bmat(2,3*nn-1);
    GeMat(7:9,3*nn-2:3*nn) = I3*Bmat(3,3*nn);
end
