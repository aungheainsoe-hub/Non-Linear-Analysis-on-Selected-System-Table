function se = tet10Smat(~,NodalCoordinates)

% This function calculates element convective stiffness matrix


% Convective stiffness matrix
se = zeros(30);


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [~, detJ, dNi] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    seTemp = zeros(30);
    
    for ii = 1:10
        for jj = 1:10
            
            dj_dz = dNi(3,jj);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            dj_dy = dNi(2,jj);
            y_j = NodalCoordinates(jj,2);
            z_j = NodalCoordinates(jj,3);
            
            di_dz = dNi(3,ii);
            di_dy = dNi(2,ii);
            y_i = NodalCoordinates(ii,2);
            z_i = NodalCoordinates(ii,3);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            a_ij = (dj_dz*y_j-dj_dy*z_j)*(di_dz*y_i-di_dy*z_i);
            
            seTemp(3*ii-2:3*ii,3*jj-2:3*jj) = diag([a_ij a_ij a_ij]);
        end
    end
    
    se = se +w_i(nn)*seTemp*1/6*detJ;
    
end

