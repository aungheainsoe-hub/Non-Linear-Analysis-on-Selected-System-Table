function  F_gravityElementVec = hex8F_gravityVec(material,NodalCoordinates,accelerationVec)

% This function calculates element centrifugal force vector

% Centrifugal force vector
F_gravityElementVec = zeros(24,1);


% 2x2x2 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(1/3) sqrt(1/3)];
w_i = [1 1];


for nn = 1:2
    for mm = 1:2
        for LL = 1:2
            %
            [~, detJ, ~] = hex8Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Nmat = hex8Nmat(x_i(nn),x_i(mm),x_i(LL));
            
            for nodeID = 1:8
                
                F_gravityElementVec(3*nodeID-2:3*nodeID) = ...
                    F_gravityElementVec(3*nodeID-2:3*nodeID) ...
                    +w_i(LL)*w_i(mm)*w_i(nn)*Nmat(:,3*nodeID-2:3*nodeID)'*accelerationVec*detJ;
            end
        end
    end
end

F_gravityElementVec = material.rho*F_gravityElementVec;
