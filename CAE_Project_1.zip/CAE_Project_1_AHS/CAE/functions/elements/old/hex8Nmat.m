function Nmat = hex8Nmat(xi,eta,zeta)

% This function calculates element shape functions

% Shape functions
% Nf = [Nf1
%       Nf2
%       ...
%       Nfn];
%
Nf = [ -((eta - 1)*(xi - 1)*(zeta - 1))/8
    ((eta - 1)*(xi + 1)*(zeta - 1))/8
    -((eta + 1)*(xi + 1)*(zeta - 1))/8
    ((eta + 1)*(xi - 1)*(zeta - 1))/8
    ((eta - 1)*(xi - 1)*(zeta + 1))/8
    -((eta - 1)*(xi + 1)*(zeta + 1))/8
    ((eta + 1)*(xi + 1)*(zeta + 1))/8
    -((eta + 1)*(xi - 1)*(zeta + 1))/8];


% Shape function matrix
Nmat = zeros(3,24);

% Ni = [Nfi 0   0
%       0   Nfi 0
%       0   0   Nfi];
% 
% N = [N1 N2 ... Nn];

for nn = 1:8
%
Nmat(1,(nn-1)*3+1) = Nf(nn);
Nmat(2,(nn-1)*3+2) = Nf(nn);
Nmat(3,(nn-1)*3+3) = Nf(nn);

end

