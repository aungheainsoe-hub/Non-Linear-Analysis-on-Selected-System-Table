function stressVec = hex20Stress(material,NodalCoordinates,uElement)

% This function calculates stress vector

Dmat = DmatIsotropic3D(material);

[Bmat, ~, ~] = hex20Bmat_detJ_dNi(0,0,0,NodalCoordinates);

stressVec = Dmat*Bmat*uElement;

% % Stress vector
% stressVec = zeros(6,1);
% 
% 
% % 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% % weigth coefficients
% x_i = [-sqrt(3/5) 0 sqrt(3/5)];
% w_i = [5/9 8/9 5/9];
% 
% 
% for nn = 1:3
%     for mm = 1:3
%         for LL = 1:3
%             
%             [Bmat, detJ, ~] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
%             
%             stressVec = stressVec +w_i(LL)*w_i(mm)*w_i(nn)*Dmat*Bmat*uElement;
%             
%         end
%     end
% end


% xMat = sqrt(3/5)*[-1 1 1 -1 -1 1 1 -1 0 1 0 -1 0 1 0 -1 -1 1 1 -1
%                   -1 -1 1 1 -1 -1 1 1 -1 0 1 0 -1 0 1 0 -1 -1 1 1
%                   -1 -1 -1 -1 1 1 1 1 -1 -1 -1 -1 1 1 1 1 0 0 0 0];
% %
% 
% Wmat = [5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 8/9 5/9 8/9 5/9 8/9 5/9 8/9 5/9 5/9 5/9 5/9 5/9
%         5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 8/9 5/9 8/9 5/9 8/9 5/9 8/9 5/9 5/9 5/9 5/9
%         5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 5/9 8/9 8/9 8/9 8/9];
% %
% 
% 
% for nn = 1:20
%     %
%     x_inn = xMat(1,nn);
%     x_imm = xMat(2,nn);
%     x_iLL = xMat(3,nn);
%     
%     w_iLL = Wmat(1,nn);
%     w_imm = Wmat(2,nn);
%     w_inn = Wmat(3,nn);
%     
%     [Bmat, detJ, ~] = hex20Bmat_detJ_dNi(x_inn,x_imm,x_iLL,NodalCoordinates);
%     
%     stressVec = stressVec +w_iLL*w_imm*w_inn*Dmat*Bmat*uElement;
%     
% end
