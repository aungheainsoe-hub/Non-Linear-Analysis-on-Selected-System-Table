function  F_OmegaElementVec = hex20F_OmegaVec(material,NodalCoordinates)

% This function calculates element centrifugal force vector

% Centrifugal force vector
F_OmegaElementVec = zeros(60,1);


% wTw = [Omega']*[Omega], spin around global X-axis
wTw = [0 0 0
       0 1 0
       0 0 1];
%


% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(3/5) 0 sqrt(3/5)];
w_i = [5/9 8/9 5/9];


for nn = 1:3
    for mm = 1:3
        for LL = 1:3
            %
            [~, detJ, ~] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Nmat = hex20Nmat(x_i(nn),x_i(mm),x_i(LL));
            
            for nodeID = 1:20
                
                F_OmegaElementVec(3*nodeID-2:3*nodeID) = ...
                    F_OmegaElementVec(3*nodeID-2:3*nodeID) ...
                    +w_i(LL)*w_i(mm)*w_i(nn)*Nmat(:,3*nodeID-2:3*nodeID)'*wTw*NodalCoordinates(nodeID,:)'*detJ;
            end
        end
    end
end

F_OmegaElementVec = material.rho*F_OmegaElementVec;
