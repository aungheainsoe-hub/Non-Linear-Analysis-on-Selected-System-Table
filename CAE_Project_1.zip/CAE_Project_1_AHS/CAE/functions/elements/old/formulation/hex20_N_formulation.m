
clear all, close all, clc


syms xi eta zeta real

% Monomials used
pVec = [1
        xi
        eta
        zeta
        xi*eta
        eta*zeta
        xi*zeta
        xi^2
        eta^2
        zeta^2
        xi*eta*zeta
        xi*eta^2
        xi*zeta^2
        xi^2*eta
        eta*zeta^2
        xi^2*zeta
        eta^2*zeta
        xi^2*eta*zeta
        xi*eta^2*zeta
        xi*eta*zeta^2];
%

% Node locations in element natural coordinate system
% NodeN = [xiN etaN zetaN];
Node1 = [-1 -1 -1]';

Node2 = [1 -1 -1]';

Node3 = [1 1 -1]';

Node4 = [-1 1 -1]';

Node5 = [-1 -1 1]';

Node6 = [1 -1 1]';

Node7 = [1 1 1]';

Node8 = [-1 1 1]';

Node9 = [0 -1 -1]';

Node10 = [1 0 -1]';

Node11 = [0 1 -1]';

Node12 = [-1 0 -1]';

Node13 = [0 -1 1]';

Node14 = [1 0 1]';

Node15 = [0 1 1]';

Node16 = [-1 0 1]';

Node17 = [-1 -1 0]';

Node18 = [1 -1 0]';

Node19 = [1 1 0]';

Node20 = [-1 1 0]';


NodeN = [];

for nn = 1:20
%
eval(['NodeN = [NodeN Node' num2str(nn) '];']);
end

xiVec = NodeN(1,:);
etaVec = NodeN(2,:);
zetaVec = NodeN(3,:);


Pmat = [];

for nn = 1:20
%
Pmat = [Pmat; [1
        xiVec(nn)
        etaVec(nn)
        zetaVec(nn)
        xiVec(nn)*etaVec(nn)
        etaVec(nn)*zetaVec(nn)
        xiVec(nn)*zetaVec(nn)
        xiVec(nn)^2
        etaVec(nn)^2
        zetaVec(nn)^2
        xiVec(nn)*etaVec(nn)*zetaVec(nn)
        xiVec(nn)*etaVec(nn)^2
        xiVec(nn)*zetaVec(nn)^2
        xiVec(nn)^2*etaVec(nn)
        etaVec(nn)*zetaVec(nn)^2
        xiVec(nn)^2*zetaVec(nn)
        etaVec(nn)^2*zetaVec(nn)
        xiVec(nn)^2*etaVec(nn)*zetaVec(nn)
        xiVec(nn)*etaVec(nn)^2*zetaVec(nn)
        xiVec(nn)*etaVec(nn)*zetaVec(nn)^2]'];
end


Nf = simplify(pVec'*inv(Pmat))';

simplify(sum(Nf))


% Calculating partial derivatives of shape functions with respect to
% natural coordinates, used in calculation of Jacobian matrix and strain
% matrix
Npartial = [];
for nn = 1:20
%
Npartial = [Npartial [diff(Nf(nn),xi) diff(Nf(nn),eta) diff(Nf(nn),zeta)]'];
end

Npartial = simplify(Npartial);


% Delta function testing

for nn = 1:20
%
Nfi = Nf(nn);

disp('----------------------------------')
disp(['Shape function ' num2str(nn)])

for mm = 1:20
%
xi = xiVec(mm);
eta = etaVec(mm);
zeta = zetaVec(mm);

if eval(Nfi) == 1
    disp([xi eta zeta])
end

end

disp('----------------------------------')
disp(' ')
disp(' ')

end

