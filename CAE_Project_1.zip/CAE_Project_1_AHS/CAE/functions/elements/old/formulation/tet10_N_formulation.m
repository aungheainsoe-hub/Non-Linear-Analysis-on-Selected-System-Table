
clear all, close all, clc


syms xi eta zeta real

% Monomials used
pVec = [1
        xi
        eta
        zeta
        xi*eta
        eta*zeta
        xi*zeta
        xi^2
        eta^2
        zeta^2];
%

% Node locations in element natural coordinate system
% NodeN = [xiN etaN zetaN];
Node1 = [0 0 0]';

Node2 = [1 0 0]';

Node3 = [0 1 0]';

Node4 = [0 0 1]';

Node5 = [0.5 0 0]';

Node6 = [0.5 0.5 0]';

Node7 = [0 0.5 0]';

Node8 = [0 0 0.5]';

Node9 = [0.5 0 0.5]';

Node10 = [0 0.5 0.5]';


NodeN = [];

for nn = 1:10
%
eval(['NodeN = [NodeN Node' num2str(nn) '];']);
end

xiVec = NodeN(1,:);
etaVec = NodeN(2,:);
zetaVec = NodeN(3,:);


Pmat = [];

for nn = 1:10
%
Pmat = [Pmat; [1
        xiVec(nn)
        etaVec(nn)
        zetaVec(nn)
        xiVec(nn)*etaVec(nn)
        etaVec(nn)*zetaVec(nn)
        xiVec(nn)*zetaVec(nn)
        xiVec(nn)^2
        etaVec(nn)^2
        zetaVec(nn)^2]'];
end


Nf = simplify(pVec'*inv(Pmat))';

simplify(sum(Nf))


% Calculating partial derivatives of shape functions with respect to
% natural coordinates, used in calculation of Jacobian matrix and strain
% matrix
Npartial = [];
for nn = 1:10
%
Npartial = [Npartial [diff(Nf(nn),xi) diff(Nf(nn),eta) diff(Nf(nn),zeta)]'];
end

Npartial = simplify(Npartial);


% Delta function testing

for nn = 1:10
%
Nfi = Nf(nn);

disp('----------------------------------')
disp(['Shape function ' num2str(nn)])

for mm = 1:10
%
xi = xiVec(mm);
eta = etaVec(mm);
zeta = zetaVec(mm);

if eval(Nfi) == 1
    disp([xi eta zeta])
end

end

disp('----------------------------------')
disp(' ')
disp(' ')

end

