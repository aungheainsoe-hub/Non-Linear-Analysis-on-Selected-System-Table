function kgmat = hex20KGmat(NodalCoordinates,stressVec)

% This function element stress stiffening matrix

% Stress stiffening matrix
kgmat = zeros(60);

% 3x3 identity matrix
I3 = eye(3);

% Initial stress matrix
S0 = [I3*stressVec(1) I3*stressVec(4) I3*stressVec(6)
      I3*stressVec(4) I3*stressVec(2) I3*stressVec(5)
      I3*stressVec(6) I3*stressVec(5) I3*stressVec(3)];
%

% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(3/5) 0 sqrt(3/5)];
w_i = [5/9 8/9 5/9];

for nn = 1:3
    for mm = 1:3
        for LL = 1:3
            %
            [Bmat, detJ, ~] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            GeMat = hex20GeMat(Bmat);
            
            kgmat = kgmat +w_i(LL)*w_i(mm)*w_i(nn)*GeMat'*S0*GeMat*detJ;
            
        end
    end
end


function GeMat = hex20GeMat(Bmat)

% 3x3 identity matrix
I3 = eye(3);

% Ge matrix
GeMat = zeros(9,60);

for nn = 1:20
    
    GeMat(1:3,3*nn-2:3*nn) = I3*Bmat(1,3*nn-2);
    GeMat(4:6,3*nn-2:3*nn) = I3*Bmat(2,3*nn-1);
    GeMat(7:9,3*nn-2:3*nn) = I3*Bmat(3,3*nn);
end
