function  F_deltaT_ElementVec = hex8F_deltaT_Vec(material,NodalCoordinates,elementNodal_deltaT)

% This function calculates element thermal expansion force vector

Dmat = DmatIsotropic3D(material);


% Centrifugal force vector
F_deltaT_ElementVec = zeros(24,1);


% Vector of thermal expansion coefficients
alphaVec = material.alpha*[1 1 1 0 0 0]';


% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(1/3) sqrt(1/3)];
w_i = [1 1];


for nn = 1:2
    for mm = 1:2
        for LL = 1:2
            %
            [Bmat, detJ, ~] = hex8Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            for nodeID = 1:8
                
                F_deltaT_ElementVec(3*nodeID-2:3*nodeID) = ...
                    F_deltaT_ElementVec(3*nodeID-2:3*nodeID) ...
                    +w_i(LL)*w_i(mm)*w_i(nn)*Bmat(:,3*nodeID-2:3*nodeID)'*Dmat*alphaVec*elementNodal_deltaT(nodeID)*detJ;
            end
        end
    end
end
