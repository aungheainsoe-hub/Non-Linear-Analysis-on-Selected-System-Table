function ge = tet10Gmat(material,NodalCoordinates)

% This function calculates element gyroscopic matrix

% Gyroscopic damping matrix
ge = zeros(30);


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [~, detJ, dNi] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    Nmat = tet10Nmat(xi_i(nn),eta_i(nn),zeta_i(nn));
    
    gVec = zeros(30,1);
    for kk = 1:10
        gVec(3*kk-2:3*kk) = [dNi(2,kk)*NodalCoordinates(kk,3)-dNi(3,kk)*NodalCoordinates(kk,2) -dNi(1,kk)*NodalCoordinates(kk,3) dNi(1,kk)*NodalCoordinates(kk,2)]';
    end
    
    ge = ge +w_i(nn)*[gVec zeros(30,2)]*Nmat*1/6*detJ;
    
end

ge = 1/2*material.rho*(ge -ge');
