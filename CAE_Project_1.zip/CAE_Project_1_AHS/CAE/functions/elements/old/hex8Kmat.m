function ke = hex8Kmat(material,NodalCoordinates)

% This function calculates element stiffness matrix

Dmat = DmatIsotropic3D(material);


% Stiffness matrix
ke = zeros(24);


% 2x2x2 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(1/3) sqrt(1/3)];
w_i = [1 1];


for nn = 1:2
    for mm = 1:2
        for LL = 1:2
            %
            [Bmat, detJ, ~] = hex8Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            ke = ke +w_i(LL)*w_i(mm)*w_i(nn)*Bmat'*Dmat*Bmat*detJ;
            
        end
    end
end
