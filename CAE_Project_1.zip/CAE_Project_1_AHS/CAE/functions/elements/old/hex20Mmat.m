function me = hex20Mmat(material,NodalCoordinates)

% This function calculates element mass matrix

% Mass matrix
me = zeros(60);


% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(3/5) 0 sqrt(3/5)];
w_i = [5/9 8/9 5/9];


for nn = 1:3
    for mm = 1:3
        for LL = 1:3
            %
            [~, detJ, ~] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Nmat = hex20Nmat(x_i(nn),x_i(mm),x_i(LL));
            
            me = me +w_i(LL)*w_i(mm)*w_i(nn)*(Nmat'*Nmat)*detJ;
            
        end
    end
end

me = material.rho*me;

