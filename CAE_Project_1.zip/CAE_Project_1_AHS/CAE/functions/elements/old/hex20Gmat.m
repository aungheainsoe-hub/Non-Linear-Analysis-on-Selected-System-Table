function ge = hex20Gmat(material,NodalCoordinates)

% This function calculates element gyroscopic matrix

% Gyroscopic damping matrix
ge = zeros(60);


% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(3/5) 0 sqrt(3/5)];
w_i = [5/9 8/9 5/9];


for nn = 1:3
    for mm = 1:3
        for LL = 1:3
            %
            [~, detJ, dNi] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Nmat = hex20Nmat(x_i(nn),x_i(mm),x_i(LL));
            
            gVec = zeros(60,1);
            for kk = 1:20
                gVec(3*kk-2:3*kk) = [dNi(2,kk)*NodalCoordinates(kk,3)-dNi(3,kk)*NodalCoordinates(kk,2) -dNi(1,kk)*NodalCoordinates(kk,3) dNi(1,kk)*NodalCoordinates(kk,2)]';
            end
            
            ge = ge +w_i(LL)*w_i(mm)*w_i(nn)*[gVec zeros(60,2)]*Nmat*detJ;
            
        end
    end
end

ge = 1/2*material.rho*(ge -ge');
