function stressVec = hex8Stress(material,NodalCoordinates,uElement)

% This function calculates stress vector

Dmat = DmatIsotropic3D(material);

[Bmat, ~, ~] = hex8Bmat_detJ_dNi(0,0,0,NodalCoordinates);

stressVec = Dmat*Bmat*uElement;
