function ge = hex8Gmat(material,NodalCoordinates)

% This function calculates element gyroscopic matrix

% Gyroscopic damping matrix
ge = zeros(24);


% 2x2x2 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(1/3) sqrt(1/3)];
w_i = [1 1];


for nn = 1:2
    for mm = 1:2
        for LL = 1:2
            %
            [~, detJ, dNi] = hex8Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Nmat = hex8Nmat(x_i(nn),x_i(mm),x_i(LL));
            
            ge_temp = zeros(24);
            
            for ii = 1:8
                for jj = 1:8
                    %
                    
                    dNi_dx = dNi(1,ii);
                    dNi_dy = dNi(2,ii);
                    dNi_dz = dNi(3,ii);
                    
                    N_j = Nmat(1,3*jj-2);
                    
                    y = NodalCoordinates(ii,2);
                    z = NodalCoordinates(ii,3);
                    
                    ge_temp(3*ii-2,3*jj-2) = w_i(LL)*w_i(mm)*w_i(nn)*1/2*material.rho*(-dNi_dy*N_j*z+dNi_dz*N_j*y)*detJ;
                    
                    ge_temp(3*ii-1,3*jj-2) = w_i(LL)*w_i(mm)*w_i(nn)*1/2*material.rho*(dNi_dx*N_j*z)*detJ;
                    
                    ge_temp(3*ii,3*jj-2) = w_i(LL)*w_i(mm)*w_i(nn)*1/2*material.rho*(-dNi_dx*N_j*y)*detJ;
                    
                end
            end
            
            ge = ge +ge_temp;
            
        end
    end
end

ge = ge -ge';
