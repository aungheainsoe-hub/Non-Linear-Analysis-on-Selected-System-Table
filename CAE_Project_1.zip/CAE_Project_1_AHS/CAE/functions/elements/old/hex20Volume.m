function Ve = hex20Volume(NodalCoordinates)

% This function calculates element volume

% Element volume
Ve = 0;


% 3x3x3 point integration, x_i are Gaussian integration points and w_i are
% weigth coefficients
x_i = [-sqrt(3/5) 0 sqrt(3/5)];
w_i = [5/9 8/9 5/9];


for nn = 1:3
    for mm = 1:3
        for LL = 1:3
            %
            [~, detJ, ~] = hex20Bmat_detJ_dNi(x_i(nn),x_i(mm),x_i(LL),NodalCoordinates);
            
            Ve = Ve +w_i(LL)*w_i(mm)*w_i(nn)*detJ;
            
        end
    end
end

