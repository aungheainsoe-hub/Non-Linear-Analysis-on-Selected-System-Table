function Nmat = hex20Nmat(xi,eta,zeta)

% This function calculates element shape functions

% Shape functions
% Nf = [Nf1
%       Nf2
%       ...
%       Nfn];
%
Nf = [1/8*(1-xi)*(1-eta)*(1-zeta)*(-xi-eta-zeta-2)
    1/8*(1+xi)*(1-eta)*(1-zeta)*(xi-eta-zeta-2)
    1/8*(1+xi)*(1+eta)*(1-zeta)*(xi+eta-zeta-2)
    1/8*(1-xi)*(1+eta)*(1-zeta)*(-xi+eta-zeta-2)
    1/8*(1-xi)*(1-eta)*(1+zeta)*(-xi-eta+zeta-2)
    1/8*(1+xi)*(1-eta)*(1+zeta)*(xi-eta+zeta-2)
    1/8*(1+xi)*(1+eta)*(1+zeta)*(xi+eta+zeta-2)
    1/8*(1-xi)*(1+eta)*(1+zeta)*(-xi+eta+zeta-2)
    1/4*(1-xi^2)*(1-eta)*(1-zeta)
    1/4*(1+xi)*(1-eta^2)*(1-zeta)
    1/4*(1-xi^2)*(1+eta)*(1-zeta)
    1/4*(1-xi)*(1-eta^2)*(1-zeta)
    1/4*(1-xi^2)*(1-eta)*(1+zeta)
    1/4*(1+xi)*(1-eta^2)*(1+zeta)
    1/4*(1-xi^2)*(1+eta)*(1+zeta)
    1/4*(1-xi)*(1-eta^2)*(1+zeta)
    1/4*(1-xi)*(1-eta)*(1-zeta^2)
    1/4*(1+xi)*(1-eta)*(1-zeta^2)
    1/4*(1+xi)*(1+eta)*(1-zeta^2)
    1/4*(1-xi)*(1+eta)*(1-zeta^2)];


% Shape function matrix
Nmat = zeros(3,60);

% Ni = [Nfi 0   0
%       0   Nfi 0
%       0   0   Nfi];
% 
% N = [N1 N2 ... Nn];

for nn = 1:20
%
Nmat(1,(nn-1)*3+1) = Nf(nn);
Nmat(2,(nn-1)*3+2) = Nf(nn);
Nmat(3,(nn-1)*3+3) = Nf(nn);

end

