function Dmat = DmatIsotropic3D(material)

E = material.E;
nu = material.nu;

% Matrix of material constants for isotropic material
Dmat = E/((1+nu)*(1-2*nu))* ...
    [1-nu nu   nu   0          0          0
     nu   1-nu nu   0          0          0
     nu   nu   1-nu 0          0          0
     0    0    0    (1-2*nu)/2 0          0
     0    0    0    0          (1-2*nu)/2 0
     0    0    0    0          0          (1-2*nu)/2];
%
