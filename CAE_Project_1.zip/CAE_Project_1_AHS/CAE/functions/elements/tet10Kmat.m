function ke = tet10Kmat(material,NodalCoordinates)

% This function calculates element stiffness matrix

Dmat = DmatIsotropic3D(material);


% Stiffness matrix
ke = zeros(30);


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [Bmat, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    ke = ke +w_i(nn)*Bmat'*Dmat*Bmat*1/6*detJ;
    
end


% % % % Tetrahedron 4-point numerical integration
% % % xi_i = [0.585410196624968 0.138196601125010 0.138196601125010 0.138196601125010];
% % % eta_i = [0.138196601125010 0.585410196624968 0.138196601125010 0.138196601125010];
% % % zeta_i = [0.138196601125010 0.138196601125010 0.585410196624968 0.138196601125010];
% % % w_i = [0.25 0.25 0.25 0.25];
% % % 
% % % for nn = 1:4
% % %     %
% % %     [Bmat, detJ, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
% % %     
% % %     ke = ke +w_i(nn)*Bmat'*Dmat*Bmat*1/6*detJ;
% % %     
% % % end
