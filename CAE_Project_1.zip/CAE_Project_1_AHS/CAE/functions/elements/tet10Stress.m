function stressVec = tet10Stress(material,NodalCoordinates,uElement)

% This function calculates stress vector

Dmat = DmatIsotropic3D(material);


% Stress vector
stressVec = zeros(6,1);


% Tetrahedron 5-point numerical integration
xi_i = [1/6 0.5 1/6 1/6 0.25];
eta_i = [1/6 1/6 0.5 1/6 0.25];
zeta_i = [1/6 1/6 1/6 0.5 0.25];
w_i = [0.45 0.45 0.45 0.45 -0.8];

for nn = 1:5
    %
    [Bmat, ~, ~] = tet10Bmat_detJ_dNi(xi_i(nn),eta_i(nn),zeta_i(nn),NodalCoordinates);
    
    stressVec = stressVec +w_i(nn)*Dmat*Bmat*uElement;
    
end
