function [Bmat, detJ, dNi] = tet10Bmat_detJ_dNi(xi,eta,zeta,NodalCoordinates)


% Partial derivatives of shape function with respect to natural coordinates
% Npartial = [dN1_dxi   dN2_dxi ...   dNn_dxi
%             dN1_deta  dN2_deta ...  dNn_deta
%             dN1_dzeta dN2_dzeta ... dNn_dzeta];
%
Npartial = [ 4*eta + 4*xi + 4*zeta - 3, 4*xi - 1,         0,          0, 4 - 8*xi - 4*zeta - 4*eta, 4*eta,                    -4*eta,                   -4*zeta, 4*zeta,      0
    4*eta + 4*xi + 4*zeta - 3,        0, 4*eta - 1,          0,                     -4*xi,  4*xi, 4 - 4*xi - 4*zeta - 8*eta,                   -4*zeta,      0, 4*zeta
    4*eta + 4*xi + 4*zeta - 3,        0,         0, 4*zeta - 1,                     -4*xi,     0,                    -4*eta, 4 - 4*xi - 8*zeta - 4*eta,   4*xi,  4*eta];


% Jacobian matrix, determinant and inverse
Jac = Npartial*NodalCoordinates;
detJ = det(Jac);
invJ = inv(Jac);


% Strain matrix
Bmat = zeros(6,30);

% Bi = [dNi_dx 0      0
%       0      dNi_dy 0
%       0      0      dNi_dz
%       0      dNi_dz dNi_dy
%       dNi_dz 0      dNi_dx
%       dNi_dy dNi_dx 0];
%
% B = [B1 B2 ... Bn];

for nn = 1:10
%
% Shape function partial derivatives with respect to physical coordinates
% is calculated using Jacobian matrix
% dNi = [dNi_dx dNi_dy dNi_dz]'
dNi = invJ*Npartial;

Bmat(1,(nn-1)*3+1) = dNi(1,nn);
Bmat(2,(nn-1)*3+2) = dNi(2,nn);
Bmat(3,(nn-1)*3+3) = dNi(3,nn);

Bmat(4,(nn-1)*3+1) = dNi(2,nn);
Bmat(4,(nn-1)*3+2) = dNi(1,nn);

Bmat(5,(nn-1)*3+2) = dNi(3,nn);
Bmat(5,(nn-1)*3+3) = dNi(2,nn);

Bmat(6,(nn-1)*3+1) = dNi(3,nn);
Bmat(6,(nn-1)*3+3) = dNi(1,nn);

end

