function Nmat = tet10Nmat(xi,eta,zeta)

% This function calculates element shape functions

% Shape functions
% Nf = [Nf1
%       Nf2
%       ...
%       Nfn];
%
Nf = [2*eta^2 + 4*eta*xi + 4*eta*zeta - 3*eta + 2*xi^2 + 4*xi*zeta - 3*xi + 2*zeta^2 - 3*zeta + 1
    xi*(2*xi - 1)
    eta*(2*eta - 1)
    zeta*(2*zeta - 1)
    -4*xi*(eta + xi + zeta - 1)
    4*eta*xi
    -4*eta*(eta + xi + zeta - 1)
    -4*zeta*(eta + xi + zeta - 1)
    4*xi*zeta
    4*eta*zeta];


% Shape function matrix
Nmat = zeros(3,30);

% Ni = [Nfi 0   0
%       0   Nfi 0
%       0   0   Nfi];
% 
% N = [N1 N2 ... Nn];

for nn = 1:10
%
Nmat(1,(nn-1)*3+1) = Nf(nn);
Nmat(2,(nn-1)*3+2) = Nf(nn);
Nmat(3,(nn-1)*3+3) = Nf(nn);

end

