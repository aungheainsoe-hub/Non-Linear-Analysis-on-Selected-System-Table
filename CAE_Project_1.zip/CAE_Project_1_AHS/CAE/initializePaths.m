
addpath([pwd '\functions'])
addpath([pwd '\functions\elements'])
addpath([pwd '\functions\supplementary'])
addpath([pwd '\functions\elements\old'])
